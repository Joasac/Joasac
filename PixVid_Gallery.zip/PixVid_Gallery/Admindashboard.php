<?php
session_start();
include 'includes/db.php'; // Database connection

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$loggedInUser = $_SESSION['username']; // Ensure correct session variable

// Fetch admin user details (username & profile image)
$query = "SELECT username, profile_image FROM admin WHERE username = '$loggedInUser'";
$result = mysqli_query($conn, $query);

if ($row = mysqli_fetch_assoc($result)) {
    $username = $row['username'];
    $profileImage = !empty($row['profile_image']) ? $row['profile_image'] : "assets/default_profile.png"; // Default image
} else {
    echo "Error fetching user data.";
    exit();
}

// Fetch all notifications
$notificationsQuery = "SELECT * FROM notifications ORDER BY created_at DESC"; 
$notificationsResult = mysqli_query($conn, $notificationsQuery);

// Check if there are any notifications
if ($notificationsResult) {
    $notifications = mysqli_fetch_all($notificationsResult, MYSQLI_ASSOC); 
    $totalNotifications = count($notifications);
} else {
    $notifications = []; 
    $totalNotifications = 0;
}

// Total notifications count
// $totalNotifications = $newUser + $newAdmin + $newMedia;

// Fetch counts for dashboard
$totalUsers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users"))['count'];
$totalMedia = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM media"))['count'];
$totalNotifications = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM notifications"))['count'];
$totalAdmins = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM admin"))['count'];

// Fetch users for the table
$mediaResult = mysqli_query($conn, "SELECT * FROM media");
$usersResult = mysqli_query($conn, "SELECT * FROM users");
$adminResult = mysqli_query($conn, "SELECT * FROM admin");

// Fetch counts for dashboard
$totalUsers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users"))['count'];
$totalUploadsMedia = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM media"))['count'];

// Fetch notification count
$countQuery = "SELECT COUNT(*) as total FROM notifications WHERE status = 'unread'";
$countResult = $conn->query($countQuery);
$totalNotifications = $countResult->fetch_assoc()['total'] ?? 0;

// Fetch latest notifications
$query = "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 5";
$notifications = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- favicon -->
    <link rel="icon" type="image/png" href="images/logo.png">
    <!-- Bootstrap CSS (Include in <head>) -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!--Styling-->
    <link rel="stylesheet" href="styles/style4.css">
    <link rel="stylesheet" href="styles/style5.css">
    <!-- FontAwesome for icons -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">

</head>
<body>
    <!-- Password Bar -->
    <!-- <div id="password-bar"></div> -->
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="left">
            <img src="images/logo.png" alt="Logo" class="logo"> 
            <strong>Welcome, <?php echo htmlspecialchars($loggedInUser); ?></strong>
        </div>
        <div class="right">
            <i class="fas fa-bell" id="notification-bell"></i>
            <span id="notification-count" class="badge"><?php echo $totalNotifications; ?></span>

            <!-- Notification Dropdown -->
            <div class="notification-dropdown" style="display: none;">
                <ul class="notification-list">
                    <?php if (count($notifications) > 0) { ?>
                        <?php foreach ($notifications as $notification) { ?>
                            <li class="notification-item">
                                <a href="javascript:void(0);" class="notification-link" data-id="<?php echo $notification['notification_id']; ?>" data-type="<?php echo $notification['notification_type']; ?>" data-message="<?php echo $notification['message']; ?>" data-status="<?php echo $notification['status']; ?>" data-created="<?php echo $notification['created_at']; ?>">
                                    <?php echo $notification['message']; ?>
                                </a>
                            </li>
                        <?php } ?>
                    <?php } else { ?>
                        <li class="notification-item no-notifications">No new notifications</li>
                    <?php } ?>
                </ul>
            </div>

             <!-- Profile Icon -->
            <div class="profile-dropdown">
                <?php if (!empty($profileImage)) { ?>
                    <img src="<?php echo $profileImage; ?>" class="profile-icon" id="profile-toggle" style="width: 30px; height: 30px; border-radius: 50%;">
                <?php } else { ?>
                    <i class="fas fa-user-circle profile-icon" id="profile-toggle"></i>
                <?php } ?>
                <div class="dropdown-content">
                    <a href="#" id="my-profile">My Profile</a>
                    <a href="includes/logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="main-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <h3>Admin Panel</h3>
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link" href="code.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#" id="view-user">Users</a></li>
                <li class="nav-item"><a class="nav-link" href="#" id="view-media">Media</a></li>
                <li class="nav-item"><a class="nav-link" href="#" id="view-admin">Admins</a></li>
            </ul>
        </aside>

        <!-- Main Dashboard Content -->
        <main class="dashboard-content" id="dashboard-content">
            <section class="overview">
                <h1>Dashboard Overview</h1>
                <div class="container mt-4">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="card text-white mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Total Users</h5>
                                    <p class="card-text"><?php echo $totalUsers; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-white mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Total Media</h5>
                                    <p class="card-text"><?php echo $totalMedia; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-white mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Notifications</h5>
                                    <p class="card-text"><?php echo $totalNotifications; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-white mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Total Admins</h5>
                                    <p class="card-text"><?php echo $totalAdmins; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Chart Section -->  
                    <hr>                                                         
                    <div class="row">                                                                                
                        <div class="col-md-6">
                            <canvas id="uploadsChart"></canvas>
                        </div>
                        <div class="col-md-4">
                            <canvas id="pieChart"></canvas>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-8">
                            <canvas id="lineChart"></canvas>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Users Section -->
            <section id="user-section" class="section collapsed">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <!-- Add Client Button (Left) -->
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#userModal">Add User</button>

                    <!-- Search Bar (Right) -->
                    <div class="d-flex">
                        <select id="userSearchKey" class="form-control w-auto">
                            <option value="username">Username</option>
                            <option value="email">Email</option>
                        </select>
                        <input type="text" id="userSearchInput" class="form-control w-auto ml-2" placeholder="Search">
                        <button class="btn btn-link ml-1 search-btn" onclick="searchTable('user-table', 'userSearchKey', 'userSearchInput')">
                        <i class="fas fa-search search-icon"></i>
                        </button>
                    </div>
                </div>
                <!-- <h2>Users</h2> -->
                <table class="table table-striped mt-3" id="user-table">
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <!-- <th>Password</th> -->
                            <th>Created_at</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($user = mysqli_fetch_assoc($usersResult)) { ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td data-key="username"><?php echo $user['username']; ?></td>
                                <td data-key="email"><?php echo $user['email']; ?></td>
                                <!-- <td><?php echo $user['password']; ?></td> -->
                                <td><?php echo $user['created_at']; ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm dropdown-toggle" type="button" id="actionDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Action
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="actionDropdown">
                                            <!-- View User -->
                                            <a class="dropdown-item" data-toggle="modal" data-target="#viewUserModal" data-user-id="<?php echo $user['id']; ?>" onclick="loadUserData(<?php echo $user['id']; ?>)">
                                                <i class="fas fa-eye"></i> View
                                            </a>

                                            <!-- Edit User -->
                                            <a class="dropdown-item" data-toggle="modal" data-target="#editUserModal" data-user-id="<?php echo $user['id']; ?>" onclick="loadEditUserData(<?php echo $user['id']; ?>)">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <!-- Delete User -->
                                            <a class="dropdown-item text-danger" href="includes/delete_user.php?user_id=<?php echo $user['id']; ?>" onclick="return confirm('Are you sure you want to delete this user?');">
                                                <i class="fas fa-trash-alt"></i> Delete
                                            </a>
                                            <!-- Reset Password -->
                                            <!-- <a class="dropdown-item text-warning" href="javascript:void(0);" onclick="resetPassword(<?php echo $user['id']; ?>)">
                                                <i class="fas fa-key"></i> Reset Password
                                            </a> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </section>

            <!--Admin sections -->
            <section id="administrator-section" class="section collapsed">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <!-- Add Client Button (Left) -->
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#adminModal">Add</button>

                    <!-- Search Bar (Right) -->
                    <div class="d-flex">
                        <select id="adminSearchKey" class="form-control w-auto">
                            <option value="username">username</option>
                        </select>
                        <input type="text" id="adminSearchInput" class="form-control w-auto ml-2" placeholder="Search">
                        <button class="btn btn-link ml-2" onclick="searchTable('admin-table', 'adminSearchKey', 'adminSearchInput')">
                        <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
                <!-- <h2>Users</h2> -->
                <table class="table table-striped mt-3" id="admin-table">
                    <thead>
                        <tr>
                            <th>admin ID</th>
                            <th>Username</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($admin = mysqli_fetch_assoc($adminResult)) { ?>
                            <tr>
                                <td><?php echo $admin['id']; ?></td>
                                <td data-key="username"><?php echo $admin['username']; ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm dropdown-toggle" type="button" id="actionDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Action
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="actionDropdown">
                                            <!-- View Admin -->
                                            <a class="dropdown-item" data-toggle="modal" data-target="#viewAdminModal" data-admin-id="<?php echo $admin['id']; ?>" onclick="loadAdminData(<?php echo $admin['id']; ?>)">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                            <!-- Delete Admin -->
                                            <a class="dropdown-item text-danger" href="includes/delete_admin.php?id=<?php echo $admin['id']; ?>" onclick="return confirm('Are you sure you want to delete this admin?');">
                                                <i class="fas fa-trash-alt"></i> Delete
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>     
            </section>

            <!-- Media Section -->
            <section id="media-section" class="section collapsed">
               <div class="d-flex justify-content-end mb-3">
                    <!-- Search Bar (Right) -->
                    <div class="d-flex">
                        <select id="mediaSearchKey" class="form-control w-auto">
                            <option value="user_id">User ID</option>
                            <option value="caption">Caption</option>
                        </select>
                        <input type="text" id="mediaSearchInput" class="form-control w-auto ml-2" placeholder="Search">
                        <button class="btn btn-link ml-2" onclick="searchTable('media-table', 'mediaSearchKey', 'mediaSearchInput')">
                        <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
                <!-- <h2>Media</h2> -->
                <table class="table table-striped mt-3" id="media-table">
                    <thead>
                        <tr>
                            <th>Media ID</th>
                            <th>User ID</th>
                            <th>Filename</th>
                            <th>Caption</th>
                            <th>Upload Date</th>
                            <th>Action</th>
                            <!-- <th>Enhanced</th> -->
                            <!-- <th>Created At</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($media = mysqli_fetch_assoc($mediaResult)) { ?>
                            <tr>
                                <td><?php echo $media['id']; ?></td>
                                <td data-key="user_id"><?php echo $media['user_id']; ?></td>
                                <td><?php echo $media['filename']; ?></td>
                                <td data-key="caption"><?php echo $media['caption']; ?></td>
                                <td><?php echo $media['upload_date']; ?></td>
                                <!-- <td><?php echo $media['enhanced']; ?></td> -->
                                <!-- <td><?php echo $media['created_at']; ?></td> -->
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm dropdown-toggle" type="button" id="actionDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Action
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="actionDropdown">
                                            <!-- View User -->
                                            <a class="dropdown-item" data-toggle="modal" data-target="#viewMediaModal" data-media-id="<?php echo $media['id']; ?>" onclick="loadMediaData(<?php echo $media['id']; ?>)">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                            <!-- Delete User -->
                                            <a class="dropdown-item text-danger" href="includes/delete_media.php?media_id=<?php echo $media['id']; ?>" onclick="return confirm('Are you sure you want to delete this user?');">
                                                <i class="fas fa-trash-alt"></i> Delete
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </section>

            <!-- Profile Section -->
            <section id="profile-section" style="section collapsed">
                <div class="container1 ">
                    <div class="row">
                        <!-- Left Section: User Information -->
                        <div class="col-md-6 text-center">
                            <div class="profile-image ms-4">
                                <!-- Display profile image or default icon -->
                                <?php if (!empty($profileImage)) { ?>
                                        <img src="<?php echo $profileImage; ?>" alt="Profile Image" 
                                        class="img-fluid rounded-circle" 
                                        style="width: 150px; height: 150px; object-fit: cover; object-position: center;">
                                <?php } else { ?>
                                    <i class="fa fa-user-circle" style="font-size: 150px; color: gray;"></i>
                                <?php } ?>
                            </div>
                            <div class="user-info">
                                <p><strong>Username:</strong> <span><?php echo $username; ?></span></p>
                            </div>
                        </div>

                        <!-- Right Section: Profile Image and Update Info Toggle -->
                        <div class="col-md-6 border-start">
                            <div class="toggle-buttons text-center mb-3">
                                <button class="btn btn-primary me-2" onclick="showSection('profile_image-section')">Profile</button>
                                <button class="btn btn-secondary" onclick="showSection('update-info-section')">Update</button>
                            </div>
                            <!-- Profile Image Section -->
                            <div id="profile_image-section" class="section-content text-center">
                                <h3>Profile Image</h3>
                                <div class="profile_image">
                                    <?php
                                        $file_ext = isset($data['filename']) ? strtolower(pathinfo($data['filename'], PATHINFO_EXTENSION)) : '';
                                        if (!empty($data['filename']) && in_array($file_ext, ['jpg', 'jpeg', 'png'])) {
                                            echo "<img src='uploads/profile/{$data['filename']}' class='file-view' id='profile_image-img' alt='Profile Image'>";
                                        } else {
                                            echo "<i class='fa fa-user-circle' id='default-profile_image' style='font-size: 150px; color: gray;'></i>";
                                        }
                                    ?>
                                    <input type="file" id="profile_image-input" style="display: none;" accept="image/*">
                                    <button class="btn btn-success mt-2" id="upload-profile_image">Upload</button>
                                    <button class="btn btn-danger mt-2" id="delete-profile_image">Delete</button>
                                </div>
                            </div>
                            <!-- Update Information Section -->
                            <div id="update-info-section" class="section-content" style="display: none;">
                                <h3>Update Information</h3>
                                <form id="update-info-form" method="POST" action="includes/update_profile.php">
                                    <div class="mb-2">
                                        <label for="new-username" class="form-label">Username</label>
                                        <input type="text" name="username" class="form-control" id="new-username" required>
                                    </div>
                                    <div class="mb-2">
                                        <label for="old-password" class="form-label">Old Password</label>
                                        <input type="password" name="old_password" class="form-control" id="old-password" required>
                                    </div>
                                    <div class="mb-2">
                                        <label for="new-password" class="form-label">New Password</label required>
                                        <input type="password" name="new_password" class="form-control" id="new-password">
                                    </div>
                                    <div class="mb-2">
                                        <label for="confirm-password" class="form-label">Confirm New Password</label required>
                                        <input type="password"name="confirm_password" class="form-control" id="confirm-password">
                                    </div>
                                    <button type="submit" class="btn btn-primary w-100">Update</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Notification Details Container (Hidden Initially) -->
            <section class="notification-details-container" id="notification-section" style="section collapsed">
                <div class="notification-details">
                    <h1>Notification Details</h1>
                    <p><strong>Type:</strong> <span id="notification-type"></span></p>
                    <p><strong>Message:</strong> <span id="notification-message"></span></p>
                    <p><strong>Status:</strong> <span id="notification-status"></span></p>
                    <p><strong>Created At:</strong> <span id="notification-created"></span></p>
                </div>
            </section>
        </main>
    </div>

    <!-- Add User Modal -->
    <div class="modal fade" id="userModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add User</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action="includes/save_user.php" method="POST">
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" name="username" id="username" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" id="password" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div class="modal fade" id="editUserModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit User</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action="includes/edit_user.php" method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="user_id" id="edit_user_id">
                        <div class="form-group">
                            <label for="edit_username">Username</label>
                            <input type="text" class="form-control" name="username" id="edit_username" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_email">Email</label>
                            <input type="email" class="form-control" name="email" id="edit_email" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View User Modal -->
    <div class="modal fade" id="viewUserModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">View User</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="user-info">
                        <p><strong>User ID:</strong> <span id="view_user_id"></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Username:</strong> <span id="view_username"></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Email:</strong> <span id="view_email"></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Created At:</strong> <span id="view_created_at"></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- View Media Modal -->
    <div class="modal fade" id="viewMediaModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">View Media</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body text-center">
                    <img id="mediaImage" src="" alt="Media Image" class="img-fluid">
                    <p class="mt-2"><strong>Caption:</strong> <span id="mediaCaption"></span></p>
                    <p><strong>Uploaded Date:</strong> <span id="mediaUploadDate"></span></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Admin Modal -->
    <div class="modal fade" id="adminModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Admin</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action="includes/save_admin.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" name="username" id="username" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" id="password" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Admin Modal -->
    <div class="modal fade" id="viewAdminModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">View Admin</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body text-center">
                    <div class="profile-image mb-3">
                        <img id="view_admin_profile" src="" alt="Admin Image" class="img-fluid rounded-circle" 
                        style="width: 150px; height: 150px; object-fit: cover; object-position: center;">
                        <i id="view_admin_icon" class="fas fa-user-circle fa-5x text-muted"></i>
                    </div>
                    <p><strong>Admin ID:</strong> <span id="view_admin_id"></span></p>
                    <p><strong>Username:</strong> <span id="view_username"></span></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2025 PixVid Gallery | All Rights Reserved. Zac</p>
    </footer>


    <!-- Bootstrap JS (for modal functionality) -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Bootstrap JS (Required for dropdown) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="styles/script1.js"></script>


    <script>

        //bar chart
        const ctx = document.getElementById('uploadsChart').getContext('2d');                                      
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Users', 'Total Media Uploads', 'Total Admins'], 
                datasets: [{
                    label: 'Total Count',
                    data: [<?php echo $totalUsers; ?>, <?php echo $totalUploadsMedia; ?>, <?php echo $totalAdmins; ?>], 
                    backgroundColor: 'rgba(14, 125, 125, 0.6)', 
                    borderColor: 'rgb(15, 121, 121)', 
                    borderWidth: 3
                }]
            },
            options: {
                scales: {
                    y: { 
                        beginAtZero: true 
                    }
                }
            }
        });

        // Pie chart
        const pieCtx = document.getElementById('pieChart').getContext('2d');
        new Chart(pieCtx, {
            type: 'pie',
            data: {
                labels: ['Users', 'Media', 'Admin'], 
                datasets: [{
                    label: 'Distribution',
                    data: [<?php echo $totalUsers; ?>, <?php echo $totalUploadsMedia; ?>, <?php echo $totalAdmins; ?>], 
                    backgroundColor: ['#22A99F', '#FFB55D', '#FF6B6B'], 
                    borderColor: ['#16A9A3', '#FF9F1C', '#FF3D29'], 
                    borderWidth: 3
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                return tooltipItem.label + ': ' + tooltipItem.raw;
                            }
                        }
                    }
                }
            }
        });

        // Line chart
        const lineCtx = document.getElementById('lineChart').getContext('2d');
        new Chart(lineCtx, {
            type: 'line',
            data: {
                labels: ['Users', 'Media', 'Admins'],
                datasets: [{
                    label: 'Line Chart',
                    data: [<?php echo $totalUsers; ?>, <?php echo $totalUploadsMedia; ?>, <?php echo $totalAdmins; ?>], 
                    fill: false,
                    borderColor: '#007bff',
                    tension: 0.4
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

    </script>
</body>
</html>
