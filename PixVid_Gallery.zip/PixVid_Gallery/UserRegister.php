<?php
session_start(); // Start session for user registration
include 'includes/db.php'; // Include the database connection

$error = '';
$success = '';

// Handle user registration
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    // Capture user details from the form
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    // Check if the username or email already exists
    $sql_check = "SELECT * FROM users WHERE username = '$username' OR email = '$email'";
    $result_check = mysqli_query($conn, $sql_check);

    if (mysqli_num_rows($result_check) > 0) {
        $error = "Username or Email already exists!";
    } else {
        // Hash the password before storing it
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert the new user into the database
        $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashed_password')";
        
        if (mysqli_query($conn, $sql)) {
            $success = "Registration successful. You can now login!";
            header("Location: Login.php"); // Redirect to login page after successful registration
            exit();
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PixVid Gallery User Registration</title>
    <!-- favicon -->
    <link rel="icon" type="image/png" href="images/logo.png">
    <!-- Bootstrap CSS (Include in <head>) -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!--Styling-->
    <link rel="stylesheet" href="styles/style1.css">   
    <!-- FontAwesome for icons -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">
</head>

<body class="background-radial-gradient">
    <section class="vh-100 login-section">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col col-xl-10">
                    <div class="card login-card">
                        <div class="row g-0">
                            

                            <!-- Left Section with Background Color -->
                            <div class="col-md-6 col-lg-5 d-flex align-items-center justify-content-center" style="background: linear-gradient(to right, #008888, #00cccc); padding: 30px;">
                                <div class="text-center text-white">
                                    <h2 class="display-4" style="font-family: 'Quicksand', sans-serif; font-weight: bold;">PixVid Gallery</h2>
                                    <p class="lead" style="font-family: 'Quicksand', sans-serif;">Snap. Keep. Inspire.</p>
                                </div>
                            </div>

                            <!-- Right Section -->
                            <div class="col-md-6 col-lg-7 d-flex align-items-center">
                                <div class="card-body p-4 p-lg-5 text-black">
                                    <form method="POST" action="" id="signupForm">
                                        <div class="d-flex align-items-center mb-3 pb-1">
                                            <i class="fas fa-camera fa-2x me-3" style="color: #008888;"></i>
                                            <span class="h1 fw-bold mb-0">Sign Up</span>
                                        </div>
                                        <!-- <h5 class="fw-normal mb-3 pb-3">Sign Up</h5> -->

                                        <?php if (isset($error) && !empty($error)): ?>
                                            <div class="error-message" style="display: block;"><?php echo $error; ?></div>
                                        <?php endif; ?>
                                        <div id="success-message" class="success-message">
                                            <?php if (!empty($success)) echo $success; ?>
                                        </div>

                                        <div class="form-outline mb-4">
                                            <input type="text" id="username" name="username" class="form-control form-control-lg" required />
                                            <label class="form-label" for="username">Username</label>
                                        </div>

                                        <div class="form-outline mb-4">
                                            <input type="email" id="email" name="email" class="form-control form-control-lg" required />
                                            <label class="form-label" for="email">Email</label>
                                        </div>

                                        <div class="form-outline mb-4">
                                            <input type="password" id="password" name="password" class="form-control form-control-lg" required />
                                            <label class="form-label" for="password">Password</label>
                                        </div>

                                        <!-- Remember Me Checkbox -->
                                        <div class="form-outline mb-4">
                                            <input type="checkbox" id="remember" name="remember" class="form-check-input" />
                                            <label class="form-label" for="remember">Remember Me</label>
                                        </div>

                                        <div class="pt-1 mb-4">
                                            <button class="btn btn-dark btn-lg btn-block" name="register" type="submit">Register</button>
                                        </div>

                                        <div class="text-center">
                                            <p>Already have an account? <a href="Login.php">Login</a></p>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Bootstrap JS (Required for dropdown) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
