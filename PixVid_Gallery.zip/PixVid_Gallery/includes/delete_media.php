<?php
include 'db.php';

if (isset($_GET['media_id'])) { 
    $media_id = $_GET['media_id'];  

    
    $sql = "DELETE FROM media WHERE id = ?";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $media_id);  

        if ($stmt->execute()) {
            header("Location: ../Admindashboard.php?success=Client deleted successfully");
            exit(); 
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    $conn->close();
}
?>
