<?php
session_start();
include 'db.php'; // Ensure database connection

if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if a file is uploaded
if (isset($_FILES['profile_image'])) {
    $target_dir = "../uploads/profile/"; // Ensure the folder exists
    $profile_image = $_FILES['profile_image']['name'];
    $target_file = $target_dir . basename($profile_image);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Allowed file types
    $allowed_types = ['jpg', 'jpeg', 'png'];

    if (!in_array($imageFileType, $allowed_types)) {
        echo "Only JPG, JPEG, and PNG files are allowed.";
        exit();
    }

    // Ensure the file does not already exist
    if (file_exists($target_file)) {
        echo "Sorry, the file already exists.";
        exit();
    }

    // Get the current profile image from the database to delete it
    $query = "SELECT profile_image FROM users WHERE id='$user_id'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $current_image = $row['profile_image'];

    // Delete the old profile image from the server if it exists
    if (!empty($current_image) && file_exists("../" . $current_image)) {
        unlink("../" . $current_image);
    }

    // Attempt to move the uploaded file to the target directory
    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $target_file)) {
        // Update the profile image in the database with the new file name (not the full path)
        $new_profile_image = "uploads/profile/" . $profile_image;
        $update_query = "UPDATE users SET profile_image='$new_profile_image' WHERE id='$user_id'";

        if (mysqli_query($conn, $update_query)) {
            echo "Profile image updated successfully!";
        } else {
            echo "Error updating avatar in the database.";
        }
    } else {
        echo "Error uploading file.";
    }
} else {
    echo "No file selected.";
}
?>
