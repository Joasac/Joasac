<?php
include 'db.php';

if (isset($_GET['notification_id'])) {
    $notification_id = $_GET['notification_id'];

    // Prepare SQL query
    $stmt = $conn->prepare("SELECT notification_id, notification_type, message, status, created_at FROM notifications WHERE notification_id = ?");
    $stmt->bind_param("s", $notification_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode($row);
    } else {
        echo json_encode(['error' => 'Notification not found']);
    }
    $stmt->close();
} else {
    echo json_encode(['error' => 'Invalid request']);
}
?>
