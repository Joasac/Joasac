<?php
include 'db.php';

if (isset($_GET['user_id'])) { 
    $user_id = $_GET['user_id'];  

    
    $sql = "DELETE FROM users WHERE id = ?";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $user_id);  

        if ($stmt->execute()) {
            header("Location: ../Admindashboard.php?success=Client deleted successfully");
            exit(); 
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    $conn->close();
}
?>
