<?php
include 'db.php';

$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

// Insert the new admin into the admin table
$query = "INSERT INTO admin (username, password) VALUES ('$username', '$password')";
if (mysqli_query($conn, $query)) {
    // If admin is added successfully, insert the notification
    $notification_message = "A new Admin has been added: $username"; // Use $username instead of $name
    $notification_type = "Admin"; // Type of notification

    // Insert notification into the notifications table
    $insert_notification = "INSERT INTO notifications (notification_type, message) VALUES ('$notification_type', '$notification_message')";
    mysqli_query($conn, $insert_notification);

    // Redirect to the dashboard with a success message
    header("Location: ../Admindashboard.php?success=Admin added!");
} else {
    // Error handling if admin insertion fails
    echo "Error: " . mysqli_error($conn);
}
?>
