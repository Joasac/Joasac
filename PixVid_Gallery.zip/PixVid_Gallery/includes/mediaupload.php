<?php
session_start();
include("db.php"); // Ensure you have a database connection file

$msg = "";

// If upload button is clicked
if (isset($_POST['upload'])) {
    $user_id = $_SESSION['user_id']; // Assuming user session stores user ID
    $caption = mysqli_real_escape_string($conn, $_POST['caption']);
    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];
    
    // Use relative path to 'uploads' folder
    $folder = "../uploads/" . basename($filename); // Going up one directory level to access 'uploads'
    $upload_date = date("Y-m-d H:i:s");

    // Ensure file is an image or video
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'mp4', 'mov', 'avi'];
    $file_ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

    if (!in_array($file_ext, $allowed_types)) {
        $msg = "Invalid file type. Only images and videos are allowed.";
    } else {
        // Insert into database
        $sql = "INSERT INTO media (user_id, filename, caption, upload_date, enhanced, created_at) 
                VALUES ('$user_id', '$filename', '$caption', '$upload_date', 'no', NOW())";

        if (mysqli_query($conn, $sql)) {
            if (move_uploaded_file($tempname, $folder)) {
                $msg = "File uploaded successfully!";
                // Redirect to the user dashboard after successful upload
                header("Location: ../userdashboard.php");
                exit(); // Ensure the script stops executing after the redirect
            } else {
                $msg = "Failed to upload file.";
            }
        } else {
            $msg = "Database error: " . mysqli_error($conn);
        }
    }
}
?>
