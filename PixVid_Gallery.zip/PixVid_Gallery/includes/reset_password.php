<?php
session_start();
include 'db.php'; // Database connection

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    
    $newPassword = "admin";
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Update the password in the database
    $updateQuery = "UPDATE users SET password = '$hashedPassword' WHERE id = '$id'";
    if (mysqli_query($conn, $updateQuery)) {
        echo json_encode(["status" => "success", "password" => $newPassword]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to reset password."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request."]);
}
?>
