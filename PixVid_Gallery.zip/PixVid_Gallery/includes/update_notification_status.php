<?php
include 'db.php';

if (isset($_POST['notification_id'])) {
    $notification_id = $_POST['notification_id'];

    // Update the notification status to "read"
    $stmt = $conn->prepare("UPDATE notifications SET status = 'read' WHERE notification_id = ?");
    $stmt->bind_param("s", $notification_id);
    
    if ($stmt->execute()) {
        // Return success
        echo json_encode(['success' => true]);
    } else {
        // Return failure
        echo json_encode(['success' => false]);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
?>
