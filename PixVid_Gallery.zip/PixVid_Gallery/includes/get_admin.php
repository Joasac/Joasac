<?php
include 'db.php';

if (isset($_GET['id'])) {
    $adminId = $_GET['id'];

    $query = "SELECT id, username, profile_image FROM admin WHERE id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $adminId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($admin = $result->fetch_assoc()) {
        header('Content-Type: application/json');
        echo json_encode($admin);
    } else {
        echo json_encode(["error" => "admin not found"]);
    }
    
    $stmt->close();
    $conn->close();
}
?>
