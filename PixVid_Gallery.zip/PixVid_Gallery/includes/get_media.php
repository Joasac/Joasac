<?php
include 'db.php';

if (isset($_GET['media_id'])) {
    $mediaId = $_GET['media_id'];
    $query = "SELECT * FROM media WHERE id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $mediaId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($media = $result->fetch_assoc()) {
        echo json_encode($media);
    } else {
        echo json_encode(["error" => "Media not found"]);
    }
    
    $stmt->close();
    $conn->close();
}
?>
