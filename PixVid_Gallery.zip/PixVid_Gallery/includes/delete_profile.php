<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_SESSION['profile_image'])) {
        $profileImagePath = $_SESSION['profile_image'];

        // Check if the file exists and delete it
        if (file_exists($profileImagePath)) {
            unlink($profileImagePath); // Delete the image file
            unset($_SESSION['profile_image']); // Remove image path from session (or update DB)
            echo "Profile image deleted successfully.";
        } else {
            echo "Profile image file not found.";
        }
    } else {
        echo "No profile image to delete.";
    }
}
?>
