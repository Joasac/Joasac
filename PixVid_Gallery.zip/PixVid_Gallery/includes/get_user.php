<?php
include 'db.php';

if (isset($_GET['user_id'])) {
    $userId = $_GET['user_id'];
    $query = "SELECT * FROM users WHERE id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($user = $result->fetch_assoc()) {
        echo json_encode($user);
    } else {
        echo json_encode(["error" => "User not found"]);
    }
    
    $stmt->close();
    $conn->close();
}
?>
