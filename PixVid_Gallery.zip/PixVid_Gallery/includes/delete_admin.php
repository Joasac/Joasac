<?php
include 'db.php';

$id = $_GET['id'];
$query = "DELETE FROM admin WHERE id = '$id'";

if (mysqli_query($conn, $query)) {
    header("Location: ../Admindashboard.php?success=Admin deleted!");
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
