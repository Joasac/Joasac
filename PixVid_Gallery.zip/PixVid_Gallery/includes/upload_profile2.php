<?php
session_start();
include 'db.php'; // Ensure database connection

if (!isset($_SESSION['admin_id'])) {
    header("Location: Login.php");
    exit();
}

$id = $_SESSION['admin_id']; // Use 'admin_id' as per your admin table

// Ensure the upload directory exists
$target_dir = "../uploads1/";
if (!is_dir($target_dir)) {
    mkdir($target_dir, 0777, true); // Create directory if it doesn't exist
}

// Check if a file is uploaded
if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
    $profile_image = basename($_FILES['profile_image']['name']);
    $target_file = $target_dir . $profile_image;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Allowed file types
    $allowed_types = ['jpg', 'jpeg', 'png'];
    if (!in_array($imageFileType, $allowed_types)) {
        echo "Only JPG, JPEG, and PNG files are allowed.";
        exit();
    }

    // Check if the file already exists
    if (file_exists($target_file)) {
        echo "Sorry, the file already exists.";
        exit();
    }

    // Fetch the current profile image from the database
    $stmt = $conn->prepare("SELECT profile_image FROM admin WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $current_image = $row['profile_image'] ?? '';

    // Delete the old profile image from the server if it exists
    if (!empty($current_image) && file_exists($current_image)) {
        unlink($current_image);
    }

    // Move the uploaded file to the target directory
    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $target_file)) {
        // Update the profile image in the database
        $new_profile_image = "uploads1/" . $profile_image;
        $update_stmt = $conn->prepare("UPDATE admin SET profile_image = ? WHERE id = ?");
        $update_stmt->bind_param("si", $new_profile_image, $id);

        if ($update_stmt->execute()) {
            echo "Profile image updated successfully!";
        } else {
            echo "Error updating profile image in the database.";
        }
    } else {
        echo "Error uploading file.";
    }
} else {
    echo "No file selected or an error occurred.";
}
?>
