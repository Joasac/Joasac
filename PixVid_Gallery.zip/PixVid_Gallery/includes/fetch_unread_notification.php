<?php
include 'db.php';

// Fetch only unread notifications
$query = "SELECT * FROM notifications WHERE status = 'unread' ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);

$notifications = [];

while ($row = mysqli_fetch_assoc($result)) {
    $notifications[] = $row;
}

// Check if there are no unread notifications
if (count($notifications) == 0) {
    echo json_encode(['no_notifications' => true]); // Send empty state
} else {
    echo json_encode($notifications);
}
?>
