<?php
session_start();
include 'db.php'; // Ensure this file contains the database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $old_password = trim($_POST['old_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Fetch current user data securely
    $user_id = $_SESSION['user_id']; // Ensure user_id is stored in session
    $query = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if (!$user) {
        echo "<script>alert('User not found!'); window.location.href='../userdashboard.php';</script>";
        exit();
    }

    // Verify old password
    if (!password_verify($old_password, $user['password'])) {
        echo "<script>alert('Old password is incorrect!'); window.location.href='../userdashboard.php';</script>";
        exit();
    }

    // Validate new password
    if ($new_password !== $confirm_password) {
        echo "<script>alert('New passwords do not match!'); window.location.href='../userdashboard.php';</script>";
        exit();
    }

    // Hash new password before saving
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);


    // Update user information securely
    $update_query = "UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("sssi", $username, $email, $hashed_password, $user_id);

    if ($update_stmt->execute()) {
        echo "<script>alert('Profile updated successfully!'); window.location.href='../userdashboard.php';</script>";
    } else {
        echo "<script>alert('Error updating profile!'); window.location.href='../userdashboard.php';</script>";
    }

    $update_stmt->close();
}
?>
