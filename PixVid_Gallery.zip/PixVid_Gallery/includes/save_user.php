<?php
// Include database connection
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Hash the password before storing it
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare SQL query to insert data
    $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        // Bind parameters (hashed password is stored instead of plain text)
        $stmt->bind_param("sss", $username, $email, $hashed_password);

        if ($stmt->execute()) {
            // User added successfully, now insert notification
            $notification_message = "A new user has been added: $username";
            $notification_type = "User"; // Type of notification

            // Insert notification into the notifications table
            $insert_notification = "INSERT INTO notifications (notification_type, message) VALUES (?, ?)";
            if ($notif_stmt = $conn->prepare($insert_notification)) {
                $notif_stmt->bind_param("ss", $notification_type, $notification_message);
                $notif_stmt->execute();
                $notif_stmt->close();
            }

            // Redirect back with success message
            header("Location: ../Admindashboard.php?success=User added successfully");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    // Close database connection
    $conn->close();
}
?>
