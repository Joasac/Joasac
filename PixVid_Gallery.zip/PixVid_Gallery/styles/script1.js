//Profile dropdown
document.addEventListener("DOMContentLoaded", function () {
    const profileDropdown = document.querySelector(".profile-dropdown");
    const dropdownContent = document.querySelector(".dropdown-content");

    profileDropdown.addEventListener("mouseenter", function () {
        dropdownContent.style.display = "block";
        dropdownContent.style.transition = "opacity 0.3s ease-in-out";
        dropdownContent.style.opacity = 1;
    });

    profileDropdown.addEventListener("mouseleave", function () {
        dropdownContent.style.transition = "opacity 0.3s ease-in-out";
        dropdownContent.style.opacity = 0;
        setTimeout(function () {
            dropdownContent.style.display = "none";
        }, 300); // Wait for the fade-out effect before hiding
    });
});


//Navigation
document.addEventListener("DOMContentLoaded", function () {
    const sections = document.querySelectorAll(".section");
    const dashboardOverview = document.querySelector(".overview");
    const profileSection = document.getElementById("profile-section");

    function toggleSections(sectionId) {
        sections.forEach(section => section.classList.add("collapsed"));
        dashboardOverview.style.display = "none";
        profileSection.style.display = "none"; // Hide profile-section
        document.getElementById(sectionId).classList.remove("collapsed");
    }

    document.getElementById("view-user").addEventListener("click", function (e) {
        e.preventDefault();
        toggleSections("user-section");
    });

    document.getElementById("view-media").addEventListener("click", function (e) {
        e.preventDefault();
        toggleSections("media-section");
    });

    document.getElementById("view-admin").addEventListener("click", function (e) {
        e.preventDefault();
        toggleSections("administrator-section");
    });

    document.querySelector(".nav-link[href='code.php']").addEventListener("click", function (e) {
        e.preventDefault();
        dashboardOverview.style.display = "block";
        sections.forEach(section => section.classList.add("collapsed"));
        profileSection.style.display = "none"; // Hide profile-section when viewing dashboard
    });

    // Add event listener for the "My Profile" link to show profile-section
    document.getElementById("my-profile").addEventListener("click", function (e) {
        e.preventDefault();
        profileSection.style.display = "block"; // Show profile-section
        dashboardOverview.style.display = "none"; // Hide dashboard overview
        sections.forEach(section => section.classList.add("collapsed"));
    });
});

//Fade Effects 
document.addEventListener("DOMContentLoaded", function () {
    const topBar = document.querySelector(".top-bar");
    const dashboardContent = document.querySelector(".dashboard-content");

    dashboardContent.addEventListener("scroll", function () {
        if (dashboardContent.scrollTop > 50) {
            topBar.classList.add("scrolled"); 
        } else {
            topBar.classList.remove("scrolled"); 
        }
    });
});


document.addEventListener("DOMContentLoaded", function () {
    // Get elements
    const dashboardOverview = document.querySelector(".overview");
    const sections = document.querySelectorAll(".section");
    const profileSection = document.getElementById("profile-section");

    function toggleSections(sectionId) {
        // Hide all sections
        sections.forEach(section => section.classList.add("collapsed"));

        // Hide dashboard overview
        dashboardOverview.style.display = "none";

        // Hide profile section
        profileSection.style.display = "none";

        // Show the selected section
        document.getElementById(sectionId).classList.remove("collapsed");
    }

    // Click event for "Home" to show the dashboard again
    document.querySelector(".nav-link[href='code.php']").addEventListener("click", function (e) {
        e.preventDefault();
        // Show dashboard overview
        dashboardOverview.style.display = "block";

        // Hide all sections
        sections.forEach(section => section.classList.add("collapsed"));

        // Hide profile section
        profileSection.style.display = "none";
    });

    // Click event for "My Profile"
    document.getElementById("my-profile").addEventListener("click", function () {
        // Hide all sections
        sections.forEach(section => section.classList.add("collapsed"));

        // Hide dashboard overview
        dashboardOverview.style.display = "none";

        // Show profile section
        profileSection.style.display = "block";
    });

    // Click events for sidebar links
    document.getElementById("view-user").addEventListener("click", function () {
        toggleSections("user-section");
    });

    document.getElementById("view-media").addEventListener("click", function () {
        toggleSections("media-section");
    });

    // document.getElementById("view-tokens").addEventListener("click", function () {
    //     toggleSections("tokens-section");
    // });

    // document.getElementById("view-logs").addEventListener("click", function () {
    //     toggleSections("logs-section");
    // });
});

function showSection(section) {
// Hide all sections
const sections = document.querySelectorAll('.section-content');
sections.forEach((section) => {
    section.style.display = 'none';
});

// Remove active class from all navbar buttons
const buttons = document.querySelectorAll('.nav-btn');
buttons.forEach((btn) => {
    btn.classList.remove('active');
});

// Show the clicked section
document.getElementById(section).style.display = 'block';

// Add active class to the clicked button
const activeBtn = document.querySelector(`.nav-btn[onclick="showSection('${section}')"]`);
activeBtn.classList.add('active');
}


//my profile-image
document.addEventListener("DOMContentLoaded", function () {
    const profileImg = document.getElementById("profile_image-img");
    const defaultProfileIcon = document.getElementById("default-profile_image");
    const fileInput = document.getElementById("profile_image-input");
    const uploadButton = document.getElementById("upload-profile_image");

    // Clicking the profile image or default icon opens the file input
    [profileImg, defaultProfileIcon].forEach(element => {
        if (element) element.addEventListener("click", () => fileInput.click());
    });

    // When a file is selected, preview it and upload
    fileInput.addEventListener("change", function () {
        if (fileInput.files.length === 0) return; // No file selected

        const file = fileInput.files[0];

        // Check file type
        const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
        if (!allowedTypes.includes(file.type)) {
            alert("Only JPG, JPEG, and PNG files are allowed.");
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            if (profileImg) {
                profileImg.src = e.target.result;
            } else {
                const newImg = document.createElement("img");
                newImg.src = e.target.result;
                newImg.className = "file-view";
                newImg.id = "profile_image-img";
                defaultProfileIcon.replaceWith(newImg);
                newImg.addEventListener("click", () => fileInput.click());
            }
        };
        reader.readAsDataURL(file);

        uploadProfileImage(file);
    });

    // Function to upload profile image
    async function uploadProfileImage(file) {
        try {
            let formData = new FormData();
            formData.append("profile_image", file);

            let response = await fetch("includes/upload_profile2.php", {
                method: "POST",
                body: formData,
            });

            let result = await response.text();
            alert(result); // Show response message
            location.reload(); // Refresh page to reflect the new profile image
        } catch (error) {
            console.error("Upload error:", error);
        }
    }
});


//table search 
function searchTable(tableId, searchKeyId, searchInputId) {
    let key = document.getElementById(searchKeyId).value;
    let input = document.getElementById(searchInputId).value.toLowerCase();
    let rows = document.querySelectorAll(`#${tableId} tbody tr`);

    rows.forEach(row => {
        let cell = row.querySelector(`[data-key="${key}"]`);
        row.style.display = cell && cell.textContent.toLowerCase().includes(input) ? "" : "none";
    });
}


// View User
function loadUserData(userId) {
    $.ajax({
        url: 'includes/get_user.php', // PHP script to fetch user data
        method: 'GET',
        data: { user_id: userId },
        success: function(response) {
            var user = JSON.parse(response);
            
            if (user.error) {
                alert(user.error); // Handle case if user not found
            } else {
                // Populate modal fields with user data
                $('#view_user_id').text(user.id);
                $('#view_username').text(user.username);
                $('#view_email').text(user.email);
                $('#view_created_at').text(user.created_at);
            }
        }
    });
}

// Edit User
function loadEditUserData(userId) {
    $.ajax({
        url: 'includes/get_user.php', // PHP script to fetch user data
        method: 'GET',
        data: { user_id: userId },
        success: function(response) {
            var user = JSON.parse(response);
            
            if (user.error) {
                alert(user.error); // Handle case if user not found
            } else {
                // Populate edit form fields with user data
                $('#edit_user_id').val(user.id);
                $('#edit_username').val(user.username);
                $('#edit_email').val(user.email);
            }
        }
    });
}


// View Media
function loadMediaData(mediaId) {
    $.ajax({
        url: 'includes/get_media.php', // PHP script to fetch media data
        method: 'GET',
        data: { media_id: mediaId },
        success: function(response) {
            var media = JSON.parse(response);
            
            if (media.error) {
                alert(media.error); // Handle case if media not found
            } else {
                // Populate modal fields with media data
                $('#mediaImage').attr('src', 'uploads/' + media.filename);
                $('#mediaCaption').text(media.caption);
                $('#mediaUploadDate').text(media.upload_date);
            }
        }
    });
}


// View Admin
function loadAdminData(adminId) {
    $.ajax({
        url: 'includes/get_admin.php', 
        method: 'GET',
        data: { id: adminId },
        success: function(response) {
            console.log("Raw response from PHP:", response);

            try {
                var admin = JSON.parse(response);
                console.log("Parsed admin object:", admin);

                if (admin.error) {
                    alert(admin.error);
                } else {
                    $('#view_admin_id').text(admin.id);
                    $('#view_username').text(admin.username || "N/A"); // Ensure username is displayed

                    // Fix image path based on actual folder
                    if (admin.profile_image && admin.profile_image !== "") {
                        var imagePath = admin.profile_image.startsWith("uploads1/") 
                            ? admin.profile_image 
                            : "uploads/" + admin.profile_image;

                        $('#view_admin_profile').attr('src', imagePath).show();
                        $('#view_admin_icon').hide();
                    } else {
                        $('#view_admin_profile').hide();
                        $('#view_admin_icon').show();
                    }
                }
            } catch (e) {
                console.error("Error parsing JSON:", e, response);
            }
        },
        error: function(xhr, status, error) {
            console.error("AJAX Error:", error);
        }
    });
}

//reset password
// function resetPassword(id) {
//     fetch(`includes/reset_password.php?id=${id}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data.status === "success") {
//             // Show password in the top bar
//             let passwordAlert = document.createElement("div");
//             passwordAlert.innerHTML = `Your password has been reset back to: <strong>${data.password}</strong>`;
//             passwordAlert.style.cssText = "position: fixed; top: 50px; left: 50%; transform: translateX(-50%); background: yellow; padding: 10px; z-index: 9999; font-size: 16px;";
//             document.body.appendChild(passwordAlert);

//             // Hide after 5 seconds
//             setTimeout(() => {
//                 document.body.removeChild(passwordAlert);
//             }, 5000);
//         } else {
//             alert(data.message);
//         }
//     })
//     .catch(error => console.error("Error:", error));
// }

// Notifications
document.addEventListener("DOMContentLoaded", function () {
    // Get elements
    const dashboardOverview = document.querySelector(".overview");
    const sections = document.querySelectorAll(".section");
    const notificationSection = document.getElementById("notification-section");
    const notificationDropdown = document.querySelector(".notification-dropdown");
    const notificationBell = document.getElementById("notification-bell");

    function toggleSections(sectionId) {
        // Hide all sections
        sections.forEach(section => section.classList.add("collapsed"));
        
        // Hide dashboard overview
        dashboardOverview.style.display = "none";

        // Show the selected section
        document.getElementById(sectionId).classList.remove("collapsed");
    }

    // Click event for "Home" to show the dashboard again
    document.querySelector(".nav-link[href='code.php']").addEventListener("click", function (e) {
        e.preventDefault();
        // Show dashboard overview
        dashboardOverview.style.display = "block";

        // Hide all sections
        sections.forEach(section => section.classList.add("collapsed"));

        // Hide notification section
        notificationSection.style.display = "none";
    });

    // Click event for "Notification Bell" to toggle dropdown
    notificationBell.addEventListener("click", function (event) {
        event.stopPropagation();
        notificationDropdown.style.display = notificationDropdown.style.display === "block" ? "none" : "block";
    });

    // Click event for "Notification Messages" to show notification section
    document.querySelectorAll(".notification-link").forEach(link => {
        link.addEventListener("click", function () {
            // Hide all sections
            sections.forEach(section => section.classList.add("collapsed"));
            
            // Hide dashboard overview
            dashboardOverview.style.display = "none";
            
            // Show notification section
            notificationSection.style.display = "block";
            notificationDropdown.style.display = "none"; // Hide dropdown after selection
        });
    });

    // Close dropdown when clicking outside
    document.addEventListener("click", function (event) {
        if (!notificationDropdown.contains(event.target) && !notificationBell.contains(event.target)) {
            notificationDropdown.style.display = "none";
        }
    });
});

//fetching notification
function loadNotificationData(notificationId) {
    $.ajax({
        url: 'includes/fetch_notification.php', // PHP file to fetch the data
        method: 'GET',
        data: { notification_id: notificationId },
        success: function(response) {
            try {
                var notification = JSON.parse(response);
                
                if (notification.error) {
                    alert(notification.error);
                } else {
                    // Correct field assignments
                    $('#notification-type').text(notification.notification_type);
                    $('#notification-message').text(notification.message);
                    $('#notification-status').text(notification.status);
                    $('#notification-created').text(notification.created_at);
                }
            } catch (e) {
                console.error("Error parsing JSON:", e, response);
            }
        },
        error: function(xhr, status, error) {
            console.error("AJAX Error:", status, error);
        }
    });
}
$(document).on('click', '.notification-link', function () {
    var notificationId = $(this).data('id'); // Get notification_id from the clicked item
    loadNotificationData(notificationId); // Call function to load details
});


// Mark notification as read
$(document).on('click', '.notification-link', function () {
    var notificationId = $(this).data('id'); // Get notification_id from the clicked item
    var notificationItem = $(this).closest('.notification-item'); // Get the clicked notification element

    // Call function to load details
    loadNotificationData(notificationId);

    // Update notification status to 'read'
    $.ajax({
        url: 'includes/update_notification_status.php', // New PHP file to handle the status update
        method: 'POST',
        data: { notification_id: notificationId },
        success: function(response) {
            try {
                var result = JSON.parse(response);

                if (result.success) {
                    // Remove the clicked notification from the dropdown
                    notificationItem.remove();

                    // Update the unread notification count
                    var unreadCount = parseInt($('#notification-count').text()) - 1;

                    if (unreadCount <= 0) {
                        $('#notification-count').text(0);
                        $('#notification-dropdown').html('<li class="no-notifications">No new Notification</li>');
                    } else {
                        $('#notification-count').text(unreadCount);
                    }
                } else {
                    console.error('Failed to update notification status');
                }
            } catch (e) {
                console.error("Error parsing JSON:", e, response);
            }
        },
        error: function(xhr, status, error) {
            console.error("AJAX Error:", status, error);
        }
    });
});


function loadNotifications() {
    $.ajax({
        url: 'includes/fetch_unread_notifications.php', // Modify this to your actual file
        method: 'GET',
        success: function(response) {
            try {
                var result = JSON.parse(response);
                var dropdown = $('#notification-dropdown');
                dropdown.empty(); // Clear existing notifications

                if (result.no_notifications) {
                    $('#notification-count').text(0);
                    dropdown.html('<li class="no-notifications">No new Notification</li>');
                } else {
                    $('#notification-count').text(result.length);

                    result.forEach(function(notification) {
                        var notificationItem = `
                            <li class="notification-item">
                                <a href="#" class="notification-link" data-id="${notification.id}">
                                    ${notification.message}
                                </a>
                            </li>`;
                        dropdown.append(notificationItem);
                    });
                }
            } catch (e) {
                console.error("Error parsing JSON:", e, response);
            }
        },
        error: function(xhr, status, error) {
            console.error("AJAX Error:", status, error);
        }
    });
}

// Call loadNotifications() when the page loads
$(document).ready(function() {
    loadNotifications();
});

