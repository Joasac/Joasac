<?php
session_start();
include 'includes/db.php'; 

$error = '';

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password']; 

    // Check if the user is an admin
    $sql_admin = "SELECT * FROM admin WHERE username = '$username'";
    $result_admin = mysqli_query($conn, $sql_admin);

    if ($result_admin && mysqli_num_rows($result_admin) == 1) {
        $row = mysqli_fetch_assoc($result_admin);
        if (password_verify($password, $row['password'])) { // Plain text password comparison for admin
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = 'admin';
            $_SESSION['loggedInUser'] = $row['username'];
            echo "Login successful! Redirecting...";
            header("Location: Admindashboard.php");
            exit();
        } else {
            $error = "Invalid admin username or password.";
        }
    }

    // Check if the user is a regular user
    $sql_user = "SELECT * FROM users WHERE username = '$username' OR email = '$username'";
    $result_user = mysqli_query($conn, $sql_user);

    if ($result_user && mysqli_num_rows($result_user) == 1) {
        $row = mysqli_fetch_assoc($result_user);
        if (password_verify($password, $row['password'])) { // FIXED: Now verifying hashed password
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = 'user';
            $_SESSION['loggedInUser'] = $row['username'];
            header("Location: userdashboard.php");
            exit();
        } else {
            $error = "Invalid user username/email or password.";
        }
    } else {
        $error = "Invalid username/email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PixVid Gallery Login</title>
    <link rel="icon" type="image/png" href="images/logo.png">

    <!-- favicon -->
    <link rel="icon" type="image/png" href="images/logo.png">
    <!-- Bootstrap CSS (Include in <head>) -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!--Styling-->
    <link rel="stylesheet" href="styles/style.css">
    <!-- FontAwesome for icons -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">
</head>

<body class="background-radial-gradient">

    <section class="vh-100 login-section">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col col-xl-10">
                    <div class="card login-card">
                        <div class="row g-0">
                            
                            <!-- Left Section -->
                            <div class="col-md-6 col-lg-5 d-flex align-items-center justify-content-center" style="background: linear-gradient(to right, #008888, #00cccc); padding: 30px;">
                                <div class="text-center text-white">
                                    <h2 class="display-4" style="font-family: 'Quicksand', sans-serif; font-weight: bold;">PixVid Gallery</h2>
                                    <p class="lead" style="font-family: 'Quicksand', sans-serif;">Snap. Keep. Inspire.</p>
                                </div>
                            </div>

                            <!-- Right Section -->
                            <div class="col-md-6 col-lg-7 d-flex align-items-center">
                                <div class="card-body p-4 p-lg-5 text-black">
                                    <form method="POST" action=" ">
                                        <div class="d-flex align-items-center mb-3 pb-1">
                                            <i class="fas fa-camera fa-2x me-3" style="color: #008888;"></i>
                                            <span class="h1 fw-bold mb-0">PixVid</span>
                                        </div>
                                        <h5 class="fw-normal mb-3 pb-3">Login to your account</h5>
                                        <?php if (isset($error) && !empty($error)): ?>
                                            <div class="error-message" style="display: block;"><?php echo $error; ?></div>
                                        <?php endif; ?>
                                        <?php if (isset($success)): ?>
                                            <div class="success-message"><?php echo $success; ?></div>
                                        <?php endif; ?>

                                        <div class="form-outline mb-4">
                                            <input type="text" id="username" name="username" class="form-control form-control-lg" required />
                                            <label class="form-label" for="username">Username or Email</label>
                                        </div>

                                        <div class="form-outline mb-4 position-relative">
                                            <input type="password" id="password" name="password" class="form-control form-control-lg" required />
                                            <label class="form-label" for="password">Password</label>
                                            
                                            <!-- Show Password Toggle with Checkbox (Square) -->
                                            <div class="d-flex align-items-center mt-3 mb-4">
                                                <label for="showPassword" class="form-label mb-0">Show Password</label>
                                                <input type="checkbox" id="showPassword" class="me-2" onclick="togglePasswordVisibility()" />
                                            </div>
                                        </div>

                                        <div class="pt-1 mb-4">
                                            <button class="btn btn-dark btn-lg btn-block" name="login" type="submit">Login</button>
                                        </div>

                                        <div class="text-center">
                                            <p>Don't have an account? <a href="UserRegister.php">Register</a></p>
                                        </div>

                                        <div class="text-center">
                                            <a href="forgot_password.html" class="text-muted">Forgot Password?</a>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Bootstrap JS (Required for dropdown) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

    <!-- JavaScript for form validation -->
    <script>
        document.querySelector('form').addEventListener('submit', function(event) {
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            if (username === '' || password === '') {
                event.preventDefault();
                alert('Please fill in both username and password.');
            }
        });

        // Show password toggle
        function togglePasswordVisibility() {
            var passwordInput = document.getElementById('password');
            var showPasswordCheckbox = document.getElementById('showPassword');

            if (showPasswordCheckbox.checked) {
                passwordInput.type = "text";  // Show password
            } else {
                passwordInput.type = "password";  // Hide password
            }
        }
    </script>

</body>

</html>