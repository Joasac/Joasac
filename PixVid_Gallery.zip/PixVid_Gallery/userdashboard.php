<?php
session_start();
include 'includes/db.php'; 

// Redirect if user is not logged in
if (!isset($_SESSION['loggedInUser']) || !isset($_SESSION['user_id'])) {
    header("Location: Login.php");
    exit();
}

$msg = ""; 
$loggedInUser = $_SESSION['loggedInUser'];
$user_id = $_SESSION['user_id'];

// Fetch user information (username & email)
$queryUser = "SELECT username, email, profile_image FROM users WHERE id='$user_id'";
$resultUser = mysqli_query($conn, $queryUser);

if ($resultUser && mysqli_num_rows($resultUser) > 0) {
    $userData = mysqli_fetch_assoc($resultUser);
    $username = $userData['username'];
    $email = $userData['email'];
    $profileImage = $userData['profile_image']; // Fetch profile image here
} else {
    $username = "Unknown";
    $email = "No email found";
    $profileImage = ''; // Set empty if no image is found
}

// Handle search functionality
$search_query = '';
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_query = mysqli_real_escape_string($conn, $_GET['search']);
    $queryMedia = "SELECT * FROM media WHERE user_id='$user_id' AND caption LIKE '%$search_query%' ORDER BY upload_date DESC";
} else {
    $queryMedia = "SELECT * FROM media WHERE user_id='$user_id' ORDER BY upload_date DESC";
}

// Execute the media query
$resultMedia = mysqli_query($conn, $queryMedia);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Opolot isaac Dveloper 2025 -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PixVid Gallery</title>
    <link rel="icon" type="image/png" href="images/logo.png">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles/style3.css">
    <!-- Font Awesome CDN -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top" id="navbar">
        <a class="navbar-brand" href="#">
            <img src="images/logo.png" alt="Logo" class="logo">
            <span class="nav-link">
                <strong>Welcome, <?php echo htmlspecialchars($loggedInUser); ?></strong>
            </span>
        </a>
        
        <!-- Toggler Button for Mobile View -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- Navbar Links -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <div class="navbar-nav ml-auto">
                <!-- Search Form -->
                <div class="nav-item">
                    <form method="GET" action="media_gallery.php" class="form-inline1">
                        <input type="text" name="search" class="form-control" placeholder="Search by caption..." 
                            value="<?php echo htmlspecialchars($search_query); ?>">
                        <!-- Icon as the search button -->
                        <button type="submit1" class="btn btn-link ml-2">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>

                <!-- Profile Icon with Dropdown -->
                <div class="profile-dropdown">
                    <?php if (!empty($profileImage)) { ?>
                        <img src="<?php echo $profileImage; ?>" alt="Profile Image" class="profile-icon" id="profile-toggle" style="width: 30px; height: 30px; border-radius: 50%;">
                    <?php } else { ?>
                        <i class="fas fa-user-circle profile-icon" id="profile-toggle"></i>
                    <?php } ?>
                    <div class="dropdown-content">
                        <a class="dropdown-item" id="my-profile" href="javascript:void(0);">My Profile</a>
                        <a class="dropdown-item" href="#" id="openUploadPopup">Upload</a>
                        <a class="dropdown-item" href="includes/logout.php">Logout</a>
                    </div>
                </div>   
            </div>
        </div>
    </nav>
        

    <!-- Media Gallery -->
    <section class="gallery-section" id="gallery-section">
        <div class="gallery" id="gallery-section">
            <?php if ($resultMedia && mysqli_num_rows($resultMedia) > 0) { ?>
                 <?php while ($data = mysqli_fetch_assoc($resultMedia)) { ?>
                    <div class="card">
                        <?php
                        $file_ext = strtolower(pathinfo($data['filename'], PATHINFO_EXTENSION));
                        if (in_array($file_ext, ['jpg', 'jpeg', 'png', 'gif'])) {
                            echo "<img src='uploads/{$data['filename']}' class='file-view' alt='Image'>";
                        } elseif (in_array($file_ext, ['mp4', 'mov', 'avi'])) {
                            echo "<video controls class='file-view'><source src='uploads/{$data['filename']}' type='video/$file_ext'></video>";
                        }
                        ?>
                        <div class="card-body text-center">
                            <p class="card-text"><strong>Caption:</strong> <?php echo $data['caption']; ?></p>
                            <p class="text-muted">Uploaded: <?php echo date("d | F | Y", strtotime($data['upload_date'])); ?></p>
                        </div>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <p class="nomedia text-center text-muted"><?php echo htmlspecialchars($search_query); ?></p>
            <?php } ?>
        </div>
    </section>

    <!-- Hidden Upload Popup -->
    <div id="uploadPopup" class="popup-container">
        <div class="popup-content">
            <span class="close-btn">&times;</span>
            <h2>Upload Media</h2>
            <form id="uploadForm" action="includes/mediaupload.php" method="POST" enctype="multipart/form-data">
                <input type="text" name="caption" placeholder="Enter Caption" required><br>
                <input type="file" name="uploadfile" accept="image/*,video/*" required><br>
                <button type="submit" name="upload">Upload</button>
            </form>
            <p class="text-danger"><?php echo $msg; ?></p>
        </div>
    </div>

    <div id="fullScreenViewer" class="fullscreen-viewer">
        <span class="close-viewer">&times;</span>
        <div id="viewerContent"></div>
    </div>

    <!-- Profile Section -->
    <section id="profile-section" style="display: none;">
        <div class="container ">
            <div class="row">
                <!-- Left Section: User Information -->
                <div class="col-md-6 text-center">
                    <div class="profile-image ms-4">
                        <!-- Display profile image or default icon -->
                        <?php if (!empty($profileImage)) { ?>
                            <img src="<?php echo $profileImage; ?>" alt="Profile Image" 
                                class="img-fluid rounded-circle" 
                                style="width: 150px; height: 150px; object-fit: cover; object-position: center;">
                        <?php } else { ?>
                            <i class="fa fa-user-circle" style="font-size: 150px; color: gray;"></i>
                        <?php } ?>
                    </div>
                    <div class="user-info">
                        <p><strong>Username:</strong> <span><?php echo $username; ?></span></p>
                        <p><strong>Email:</strong> <span><?php echo isset($email) ? $email : "Email not available"; ?></span></p>
                    </div>
                </div>

                <!-- Right Section: Profile Image and Update Info Toggle -->
                <div class="col-md-6 border-start">
                    <div class="toggle-buttons text-center mb-3">
                        <button class="btn btn-primary me-2" onclick="showSection('profile_image-section')">Profile Image</button>
                        <button class="btn btn-secondary" onclick="showSection('update-info-section')">Update Information</button>
                    </div>

                    <!-- Profile Image Section -->
                    <div id="profile_image-section" class="section-content text-center">
                        <h3>Profile Image</h3>
                        <div class="profile_image">
                            <?php
                                $file_ext = isset($data['filename']) ? strtolower(pathinfo($data['filename'], PATHINFO_EXTENSION)) : '';
                                if (!empty($data['filename']) && in_array($file_ext, ['jpg', 'jpeg', 'png'])) {
                                    echo "<img src='uploads/profile/{$data['filename']}' class='file-view' id='profile_image-img' alt='Profile Image'>";
                                } else {
                                    echo "<i class='fa fa-user-circle' id='default-profile_image' style='font-size: 150px; color: gray;'></i>";
                                }
                            ?>
                            <input type="file" id="profile_image-input" style="display: none;" accept="image/*">
                            <button class="btn btn-success mt-2" id="upload-profile_image">Upload</button>
                            <button class="btn btn-danger mt-2" id="delete-profile_image">Delete</button>
                        </div>
                    </div>

                    <!-- Update Information Section -->
                    <div id="update-info-section" class="section-content" style="display: none;">
                        <h3>Update Information</h3>
                        <form id="update-info-form" method="POST" action="includes/update_profile.php">
                            <div class="mb-2">
                                <label for="new-username" class="form-label">Username</label>
                                <input type="text" name="username" class="form-control" id="new-username" required>
                            </div>

                            <div class="mb-2">
                                <label for="new-email" class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" id="new-email" required>
                            </div>

                            <div class="mb-2">
                                <label for="old-password" class="form-label">Old Password</label>
                                <input type="password" name="old_password" class="form-control" id="old-password" required>
                            </div>

                            <div class="mb-2">
                                <label for="new-password" class="form-label">New Password</label required>
                                <input type="password" name="new_password" class="form-control" id="new-password">
                            </div>

                            <div class="mb-2">
                                <label for="confirm-password" class="form-label">Confirm New Password</label required>
                                <input type="password"name="confirm_password" class="form-control" id="confirm-password">
                            </div>

                            <button type="submit" class="btn btn-primary w-100">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2025 PixVid Gallery | All Rights Reserved. Zac</p>
    </footer>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script>
        // Navbar fade effect when scrolling
        window.onscroll = function() {
            let navbar = document.getElementById("navbar");
            if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
                navbar.classList.add("fade-navbar");
            } else {
                navbar.classList.remove("fade-navbar");
            }
        };



        // Open and Close Popup
        const openPopupBtn = document.getElementById("openUploadPopup");
        const uploadPopup = document.getElementById("uploadPopup");
        const closePopupBtn = document.querySelector(".close-btn");

        openPopupBtn.addEventListener("click", () => {
            uploadPopup.style.display = "flex";
        });

        closePopupBtn.addEventListener("click", () => {
            uploadPopup.style.display = "none";
        });

        window.addEventListener("click", (e) => {
            if (e.target === uploadPopup) {
                uploadPopup.style.display = "none";
            }
        });



        // Toggle between gallery and profile sections when "My Profile" is clicked
        document.getElementById("my-profile").addEventListener("click", function() {
            // Collapse the gallery container
            document.getElementById("gallery-section").style.display = "none";

            // Show the profile section
            document.getElementById("profile-section").style.display = "block";
        });

        
        // Select the overlay and close button
        const overlay = document.createElement('div');
        overlay.classList.add('fullscreen-overlay');
        document.body.appendChild(overlay);

        // When a card is clicked, open it in full-screen
        document.querySelectorAll('.card').forEach(card => {
            card.addEventListener('click', function() {
                const clonedCard = this.cloneNode(true); // Clone the clicked card content
                overlay.innerHTML = ''; // Clear the overlay content
                overlay.appendChild(clonedCard); // Add the cloned card to the overlay

                // Add close button to the overlay
                const closeBtn = document.createElement('button');
                closeBtn.classList.add('close-btn');
                closeBtn.innerHTML = '&times;';
                overlay.appendChild(closeBtn);

                // Show the overlay
                overlay.style.display = 'flex';

                // Close the overlay when the close button is clicked
                closeBtn.addEventListener('click', () => {
                    overlay.style.display = 'none';
                });
            });
        });

        // Close the overlay when clicked outside the content
        overlay.addEventListener('click', (event) => {
            if (event.target === overlay) {
                overlay.style.display = 'none';
            }
        });


        

        function showSection(section) {
        // Hide all sections
        const sections = document.querySelectorAll('.section-content');
        sections.forEach((section) => {
            section.style.display = 'none';
        });

        // Remove active class from all navbar buttons
        const buttons = document.querySelectorAll('.nav-btn');
        buttons.forEach((btn) => {
            btn.classList.remove('active');
        });

        // Show the clicked section
        document.getElementById(section).style.display = 'block';

        // Add active class to the clicked button
        const activeBtn = document.querySelector(`.nav-btn[onclick="showSection('${section}')"]`);
        activeBtn.classList.add('active');
        }



        document.addEventListener("DOMContentLoaded", function () {
            const profileImg = document.getElementById("profile_image-img");
            const defaultProfileIcon = document.getElementById("default-profile_image");
            const fileInput = document.getElementById("profile_image-input");
            const uploadButton = document.getElementById("upload-profile_image");

            // Clicking the profile image or default icon opens the file input
            [profileImg, defaultProfileIcon].forEach(element => {
                if (element) element.addEventListener("click", () => fileInput.click());
            });

            // When a file is selected, preview it and upload
            fileInput.addEventListener("change", function () {
                if (fileInput.files.length === 0) return; // No file selected

                const file = fileInput.files[0];
                const reader = new FileReader();

                reader.onload = function (e) {
                    if (profileImg) {
                        profileImg.src = e.target.result;
                    } else {
                        const newImg = document.createElement("img");
                        newImg.src = e.target.result;
                        newImg.className = "file-view";
                        newImg.id = "profile_image-img";
                        defaultProfileIcon.replaceWith(newImg);
                        newImg.addEventListener("click", () => fileInput.click());
                    }
                };

                reader.readAsDataURL(file);
                uploadProfileImage(file);
            });

            // Function to upload profile image
            async function uploadProfileImage(file) {
                try {
                    let formData = new FormData();
                    formData.append("profile_image", file);

                    let response = await fetch("includes/upload_profile.php", {
                        method: "POST",
                        body: formData,
                    });

                    let result = await response.text();
                    alert(result); // Show response message
                    location.reload(); // Refresh page to reflect the new profile image
                } catch (error) {
                    console.error("Upload error:", error);
                }
            }
        });

        document.addEventListener("DOMContentLoaded", function () {
            const deleteButton = document.getElementById("delete-profile_image");

            // Attach event listener to the delete button
            if (deleteButton) {
                deleteButton.addEventListener("click", async function () {
                    const confirmation = confirm("Are you sure you want to delete your profile image?");
                    if (confirmation) {
                        try {
                            // Send a request to delete the profile image on the server
                            let response = await fetch("includes/delete_profile.php", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify({ action: "delete" })
                            });

                            let result = await response.text();
                            alert(result); // Show response message
                            location.reload(); // Refresh page to reflect the deletion
                        } catch (error) {
                            console.error("Error deleting profile image:", error);
                        }
                    }
                });
            }
        });
    </script>

</body>
</html>

