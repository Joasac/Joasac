<?php
include 'db.php';

// Sanitize input
function clean_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Get and sanitize form data
$name = clean_input($_POST['name']);
$email = clean_input($_POST['email']);
$subject = clean_input($_POST['subject']);
$message = clean_input($_POST['message']);
$imagePath = "";

// Handle optional image upload
if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = "messages/";
    $fileName = basename($_FILES['image']['name']);
    $uniqueName = time() . "_" . $fileName;
    $targetFile = $uploadDir . $uniqueName;

    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

    if (in_array($fileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $imagePath = $targetFile;
        }
    }
}

// Insert into database
$sql = "INSERT INTO contact_messages (name, email, subject, message, image_path)
        VALUES (?, ?, ?, ?, ?)";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "sssss", $name, $email, $subject, $message, $imagePath);

if (mysqli_stmt_execute($stmt)) {
    header("Location: ../userdashboard.php?success=Message Sent successfully");
    exit();
} else {
    header("Location: ../userdashboard.php?error=Failed to send message");
    exit();}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
