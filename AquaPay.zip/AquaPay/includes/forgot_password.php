<?php
if (isset($_POST['submit'])) {
    include("db.php");  // Include your database connection

    // Sanitize input
    $email = $_POST['email'];

    // Check if the email exists in the database
    $query = "SELECT * FROM admin_users WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Generate a unique token
        $token = bin2hex(random_bytes(50));  // Secure random token

        // Store the token in the database
        $query = "UPDATE admin_users SET reset_token = ? WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $token, $email);
        $stmt->execute();

        // Create the reset link
        $resetLink = "http://yourdomain.com/reset_password.php?token=$token";

        // Send the email with the reset link
        $subject = "Password Reset Request";
        $message = "Click the following link to reset your password: $resetLink";
        $headers = "From: no-reply@yourdomain.com\r\n";
        mail($email, $subject, $message, $headers);

        echo "A reset link has been sent to your email address.";
    } else {
        echo "Email address not found.";
    }
}
?>
