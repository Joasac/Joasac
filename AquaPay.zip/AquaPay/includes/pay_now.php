<?php
session_start();
include 'db.php';

if(!isset($_SESSION['loggedInUser']) || !isset($_SESSION['client_id'])) {
    header("Location: AdminLogin.php");
    exit();
}

$loggedInUser = $_SESSION['loggedInUser'];
$client_id = $_SESSION['client_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = $_POST["amount"];
    $phone = $_POST["phone"];

    // API parameters
    $paymentApiUrl = "https://daraza.net/api/app/34/";
    $apiKey = "acd554fb-b072-4f28-a779-b5f7a6736918"; // <-- Replace with your actual API Key

    $postData = array(
        "api_key" => $apiKey,
        "phone" => $phone,
        "amount" => $amount
    );

    $ch = curl_init($paymentApiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Content-Type: application/json"
    ));

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        die("Curl error: " . curl_error($ch));
    }

    curl_close($ch);

    $result = json_decode($response, true);

    if ($result && isset($result['status']) && $result['status'] == "success") {
        // Save payment
        $payment_date = date("Y-m-d H:i:s");
        $payment_status = "Completed";
        $status = "active";
    
        $stmt = $conn->prepare("INSERT INTO payments (client_id, payment_date, amount, payment_status, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $client_id, $payment_date, $amount, $payment_status, $status);
        $stmt->execute();
        $stmt->close();
    
        // Generate token
        $token_value = strtoupper(bin2hex(random_bytes(10)));
        $issue_date = date("Y-m-d H:i:s");
        $expiry_date = date("Y-m-d H:i:s", strtotime("+30 days"));
        $token_status = "active";
    
        $stmt2 = $conn->prepare("INSERT INTO tokens (client_id, token_value, issue_date, expiry_date, status) VALUES (?, ?, ?, ?, ?)");
        $stmt2->bind_param("issss", $client_id, $token_value, $issue_date, $expiry_date, $token_status);
        $stmt2->execute();
        $stmt2->close();
    
        // Redirect with popup message
        $message = "Payment Successful. Your token is: $token_value";
        header("Location: ../userdashboard.php?popup=" . urlencode($message));
        exit();
    
    } else {
        // Payment failed
        $error = "Payment Failed: " . ($result['message'] ?? 'Unknown error.');
        header("Location: ../userdashboard.php?popup=" . urlencode($error));
        exit();
    }
    
}
?>
