<?php
include 'db.php';

// Query to get unread notifications
$query = "SELECT notification_id, notification_type, message, status, created_at FROM notifications WHERE status = 'unread'";
$result = $conn->query($query);

$unread_count = $result->num_rows; 

$notifications = [];
if ($unread_count > 0) {
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
}

echo json_encode([
    'success' => true,
    'unread_count' => $unread_count,
    'notifications' => $notifications
]);
?>
