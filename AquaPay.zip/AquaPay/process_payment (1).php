<?php  
include("dbinfo.php");
require_once("session_s.php");
require 'momo-api/src/bootstrap.php';
     
use Momoapi\Cores\Core;
use Momoapi\Cores\ApiKeys;
use Momoapi\Cores\ApiLinks;
     
$kind = $_SESSION['Kind'];
$school_id = $_SESSION['id'];
$logged = $_SESSION['Username'];
     
if(isset($_POST['file_id'])){
    $file_id = trim(mysqli_real_escape_string($db_resource, $_POST['file_id']));
}
$plan = trim(mysqli_real_escape_string($db_resource, $_POST['plan']));
$number = trim(mysqli_real_escape_string($db_resource, $_POST['number']));
$costing = trim(mysqli_real_escape_string($db_resource, $_POST['costing']));
$level = trim(mysqli_real_escape_string($db_resource, $_POST['level']));
$date = time();
     
$table = ($kind == 0) ? "exam" : "examp";
$sub = ($plan == 2 || $plan == 3) ? $plan : $file_id;
$returnedNum = formatNum($number);
    
if($returnedNum == 'num_error'){
    echo json_encode(["success" => false, "reason" => "Invalid phone number"]);
    exit;
}

// Display modern loading animation
echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Processing Payment</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .payment-container {
            display: flex;
            justify-content: center;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.85);
            z-index: 9999;
            flex-direction: column;
            font-family: 'Arial', sans-serif;
        }
        
        .spinner {
            width: 70px;
            height: 70px;
            border: 8px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: #4CAF50;
            animation: spin 1s ease-in-out infinite;
            margin-bottom: 20px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .payment-text {
            color: white;
            font-size: 24px;
            margin-bottom: 10px;
            text-align: center;
        }
        
        .payment-subtext {
            color: rgba(255,255,255,0.7);
            font-size: 16px;
            text-align: center;
            max-width: 300px;
        }
        
        .progress-bar {
            width: 300px;
            height: 8px;
            background: rgba(255,255,255,0.2);
            border-radius: 4px;
            margin-top: 20px;
            overflow: hidden;
        }
        
        .progress {
            height: 100%;
            width: 0%;
            background: #0875e1;
            border-radius: 4px;
            animation: progress 2s ease-in-out infinite;
        }
        
        @keyframes progress {
            0% { width: 0%; margin-left: 0; }
            50% { width: 100%; margin-left: 0; }
            100% { width: 0%; margin-left: 100%; }
        }
    </style>
</head>
<body>
    <div class="payment-container" id="paymentLoader">
        <div class="spinner"></div>
        <div class="payment-text">Processing Your Payment</div>
        <div class="payment-subtext">Please wait while we connect to your mobile money account. Do not close this page.</div>
        <div class="progress-bar">
            <div class="progress"></div>
        </div>
    </div>
</body>
</html>
HTML;
flush();

$response = darazaApi($returnedNum, $costing);
    
if($response['code'] == "Success"){
    // Initiate remittance after successful payment
    $remittanceResponse = initiateRemittance($costing);
    
    // Process successful payment
    if($logged == 'guest' || $logged == 'guestp'){
        // Just download the file
        $solutions = get_file($file_id, $kind, $db_resource);
        include("../download_guide.php");
        
        echo <<<HTML
        <script>
            document.getElementById('paymentLoader').style.display = 'none';
            setTimeout(function() {
                Swal.fire({
                    title: 'Payment Successful!',
                    text: 'Your download will begin shortly.',
                    icon: 'success',
                    confirmButtonColor: '#4CAF50',
                    confirmButtonText: 'Continue'
                }).then((result) => {
                    window.location.href = "../school_home.php?action=timetable&state=gold&pay=true";
                });
            }, 500);
        </script>
HTML;
    } else {
        if($plan == 2 || $plan == 3){ 
            // Update the exams table and subscriptions
            $sql = "UPDATE school SET Type = 'Gold' WHERE SchoolId = {$school_id}";
            $res = mysqli_query($db_resource, $sql);
            
            if($res){
                // Update the subscription table
                $unixDate = ($plan == 2) ? ($date - (3600*24*335)) : $date;
                
                $update = "INSERT INTO school_sub (UserID, Number, Amount, Subscription, Date, DateNow)
                          VALUES($school_id, '{$number}', '{$costing}', '{$sub}', '{$unixDate}', '{$date}')";
                $res = mysqli_query($db_resource, $update);
                
                if($res){
                    echo <<<HTML
                    <script>
                        document.getElementById('paymentLoader').style.display = 'none';
                        setTimeout(function() {
                            Swal.fire({
                                title: 'Payment Successful!',
                                text: 'Your subscription has been upgraded.',
                                icon: 'success',
                                confirmButtonColor: '#4CAF50',
                                confirmButtonText: 'Continue'
                            }).then((result) => {
                                window.location.href = "../school_home.php?action=timetable&state=gold&pay=true";
                            });
                        }, 500);
                    </script>
HTML;
                } else {
                    echo <<<HTML
                    <script>
                        document.getElementById('paymentLoader').style.display = 'none';
                        setTimeout(function() {
                            Swal.fire({
                                title: 'Database Error',
                                text: 'Failed to update subscription.',
                                icon: 'error',
                                confirmButtonColor: '#f44336',
                                confirmButtonText: 'Try Again'
                            }).then((result) => {
                                window.location.href = "../school_home.php?action=timetable&state=gold&pay=false";
                            });
                        }, 500);
                    </script>
HTML;
                }
            } else {
                echo <<<HTML
                <script>
                    document.getElementById('paymentLoader').style.display = 'none';
                    setTimeout(function() {
                        Swal.fire({
                            title: 'Database Error',
                            text: 'Failed to upgrade account.',
                            icon: 'error',
                            confirmButtonColor: '#f44336',
                            confirmButtonText: 'Try Again'
                        }).then((result) => {
                            window.location.href = "../school_home.php?action=timetable&state=gold&pay=false";
                        });
                    }, 500);
                </script>
HTML;
            }
        } else { 
            // Only update the subscriptions table
            $update = "INSERT INTO school_sub (UserID, Number, Amount, Subscription, Date, DateNow)
                      VALUES($school_id, '{$number}', '{$costing}', '{$sub}', '{$date}', '{$date}')";
            $res = mysqli_query($db_resource, $update);
            
            if($res){
                echo <<<HTML
                <script>
                    document.getElementById('paymentLoader').style.display = 'none';
                    setTimeout(function() {
                        Swal.fire({
                            title: 'Payment Successful!',
                            text: 'Your payment has been processed.',
                            icon: 'success',
                            confirmButtonColor: '#4CAF50',
                            confirmButtonText: 'Continue'
                        }).then((result) => {
                            window.location.href = "../school_home.php?action=timetable&state=gold&pay=true";
                        });
                    }, 500);
                </script>
HTML;
            } else {
                echo <<<HTML
                <script>
                    document.getElementById('paymentLoader').style.display = 'none';
                    setTimeout(function() {
                        Swal.fire({
                            title: 'Database Error',
                            text: 'Failed to record payment.',
                            icon: 'error',
                            confirmButtonColor: '#f44336',
                            confirmButtonText: 'Try Again'
                        }).then((result) => {
                            window.location.href = "../school_home.php?action=timetable&state=gold&pay=false";
                        });
                    }, 500);
                </script>
HTML;
            }
        }
    }
} else {
    // Payment failed
    $errorMsg = htmlspecialchars($response['message'], ENT_QUOTES, 'UTF-8');
    echo <<<HTML
    <script>
        document.getElementById('paymentLoader').style.display = 'none';
        setTimeout(function() {
            Swal.fire({
                title: 'Payment Failed',
                text: '{$errorMsg}',
                icon: 'error',
                confirmButtonColor: '#f44336',
                confirmButtonText: 'Try Again'
            }).then((result) => {
                window.location.href = "../school_home.php?action=timetable&state=gold&pay=false";
            });
        }, 500);
    </script>
HTML;
}
     
function formatNum($num){
    if(strlen($num) == 10 && (substr($num, 0, 3) == '077' || substr($num, 0, 3) == '078' || substr($num, 0, 3) == '076')){
        return '256' . substr($num, 1);
    }
    return 'num_error'; 
}
    
function darazaApi($number, $amount){
    $apiKey = "Enter your api key here"; // Replace with your actual API key
    $url = "https://daraza.net/api/request_to_pay/";
    
    $data = json_encode([
        "method" => 1,
        "amount" => $amount,
        "phone" => "+" . $number,
        "note" => "Checkout",
        //"reference" => "EDU_" . time() // Added reference for tracking
    ]);
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Api-Key $apiKey",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_TIMEOUT, 210); // Timeout set to 3.5 minutes (210 seconds)
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if($httpCode){
        $decoded = json_decode($response, true);
        if(isset($decoded['code']) && $decoded['code'] == 'Success'){
            return ["code" => "Success", "message" => "Payment processed successfully"];
        } else {
            return ["code" => "Error", "message" => $decoded['details'] ?? "Payment failed"];
        }
    } else {
        return ["code" => "Error", "message" => "Payment failed. Please try again later.", "details" => $response];
    }
}

function initiateRemittance($amount) {
    $apiKey = "GjWPZ6a1.jU4NcgaB9RZ3VlJlZY6Fud3XotSDKS9q"; // Replace with your actual API key
    $url = "https://daraza.net/api/remit/";
    
    $data = json_encode([
        "method" => 1,
        "amount" => $amount,
        "phone" => "+256787067441",
        "note" => "Remittance after successful payment"
    ]);
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Api-Key $apiKey",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_TIMEOUT, 210); //Timeout set to 3.5 minutes (210 seconds)
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    // You can log the remittance response for debugging
    // error_log("Remittance Response: " . print_r($response, true));
    
    return json_decode($response, true);
}

function get_file($file_id, $kind, $db_resource){
    $table = ($kind == 0) ? "exam" : "examp";
    $sql = "SELECT Solutions FROM {$table} WHERE examid = {$file_id}";
    $res = mysqli_query($db_resource, $sql);
    
    if($res){
        $row = mysqli_fetch_assoc($res);
        return $row['Solutions'];
    } else {
        return false;
    }
}