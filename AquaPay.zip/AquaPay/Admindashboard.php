<?php
session_start();
include 'includes/db.php'; // Database connection

if (!isset($_SESSION['username'])) {
    header("Location: AdminLogin.php");
    exit();
}

$loggedInUser = $_SESSION['loggedInUser']; 
$admin_id = $_SESSION['admin_id']; // Get the admin ID from session

// Fetch the admin's username, role, and profile image from the database
$query = "SELECT username, role, profile_image FROM admin_users WHERE admin_id = '$admin_id'";
$result = mysqli_query($conn, $query);

// Check if the query returns a result
if ($row = mysqli_fetch_assoc($result)) {
    $username = $row['username'];
    $role = $row['role'];
    $profileImage = $row['profile_image'];
} else {
    echo "Error fetching user data.";
    exit();
}

// Fetch all notifications
$notificationsQuery = "SELECT * FROM notifications ORDER BY created_at DESC"; 
$notificationsResult = mysqli_query($conn, $notificationsQuery);

// Check if there are any notifications
if ($notificationsResult) {
    $notifications = mysqli_fetch_all($notificationsResult, MYSQLI_ASSOC); 
    $totalNotifications = count($notifications);
} else {
    $notifications = []; 
    $totalNotifications = 0;
}

// Fetch notification counts
$newClients = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM client_information WHERE status='new'"))['count'];
$newPayments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM payments WHERE status='new'"))['count'];
$newLogs = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM system_logs WHERE status='new'"))['count'];

// Total notifications count
$totalNotifications = $newClients + $newPayments + $newLogs;

// Fetch counts for dashboard
$totalUsers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM client_information"))['count'];
$totalTokens = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM tokens"))['count'];
$totalPayments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM payments"))['count'];

// Fetch clients from DB
$clientsQuery = "SELECT * FROM client_information";
$clientsResult = mysqli_query($conn, $clientsQuery);

// Fetch payments from DB
$paymentsQuery = "SELECT * FROM payments";
$paymentsResult = mysqli_query($conn, $paymentsQuery);

// Fetch tokens from DB
$tokensQuery = "SELECT * FROM tokens";
$tokensResult = mysqli_query($conn, $tokensQuery);

// Fetch system logs from DB
$logsQuery = "SELECT * FROM system_logs";
$logsResult = mysqli_query($conn, $logsQuery);

// Fetch notification count
$countQuery = "SELECT COUNT(*) as total FROM notifications WHERE status = 'unread'";
$countResult = $conn->query($countQuery);
$totalNotifications = $countResult->fetch_assoc()['total'] ?? 0;

// Fetch latest notifications
$query = "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 5";
$notifications = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AquaPay Dashboard</title>
    <!-- favicon -->
    <link rel="icon" type="image/png" href="images/icon.png">
    <!-- Bootstrap CSS (Include in <head>) -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!--Styling-->
    <link rel="stylesheet" href="styles/style4.css">
    <link rel="stylesheet" href="styles/style.css">
    <!-- FontAwesome for icons -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">

</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="left">
            <img src="images/icon.png" alt="Logo" class="logo"> 
            <strong>Welcome, <?php echo htmlspecialchars($loggedInUser); ?></strong>
        </div>
        <div class="right">
            <i class="fas fa-bell" id="notification-bell"></i>
            <span id="notification-count" class="badge"><?php echo $totalNotifications; ?></span>

            <!-- Notification Dropdown -->
            <div class="notification-dropdown" style="display: none;">
                <ul class="notification-list">
                    <?php if (count($notifications) > 0) { ?>
                        <?php foreach ($notifications as $notification) { ?>
                            <li class="notification-item">
                                <a href="javascript:void(0);" class="notification-link" data-id="<?php echo $notification['notification_id']; ?>" data-type="<?php echo $notification['notification_type']; ?>" data-message="<?php echo $notification['message']; ?>" data-status="<?php echo $notification['status']; ?>" data-created="<?php echo $notification['created_at']; ?>">
                                    <?php echo $notification['message']; ?>
                                </a>
                            </li>
                        <?php } ?>
                    <?php } else { ?>
                        <li class="notification-item no-notifications">No new notifications</li>
                    <?php } ?>
                </ul>
            </div>

             <!-- Profile Icon -->
            <div class="profile-dropdown">
                <?php if (!empty($profileImage)) { ?>
                    <img src="<?php echo $profileImage; ?>" alt="Profile Image" class="profile-icon" id="profile-toggle" style="width: 30px; height: 30px; border-radius: 50%;">
                <?php } else { ?>
                    <i class="fas fa-user-circle profile-icon" id="profile-toggle"></i>
                <?php } ?>
                <div class="dropdown-content">
                    <a class="dropdown-item" id="my-profile" href="javascript:void(0);">My Profile</a>
                    <a class="dropdown-item" href="includes/logout.php">Logout</a>
                </div>
            </div> 
        </div>
    </div>

    <div class="main-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <h3>Admin Panel</h3>
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link" href="code.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="#" id="view-clients">Clients</a></li>
                <li class="nav-item"><a class="nav-link" href="#" id="view-payments">Payment History</a></li>
                <li class="nav-item"><a class="nav-link" href="#" id="view-tokens">Token Management</a></li>
                <li class="nav-item"><a class="nav-link" href="#" id="view-logs">System Log</a></li>
            </ul>
        </aside>

        <!-- Main Dashboard Content -->
        <main class="dashboard-content" id="dashboard-content">
            <section class="overview">
                <h1>Dashboard Overview</h1>
                <div class="container mt-4">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="card text-white mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Total Clients</h5>
                                    <p class="card-text"><?php echo $totalUsers; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-white mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Total Patients</h5>
                                    <p class="card-text"><?php echo $totalPayments; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-white mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Tokens Issued</h5>
                                    <p class="card-text"><?php echo $totalTokens; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Chart Section -->                                                           
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <canvas id="waterUsageChart"></canvas>
                        </div>
                        <div class="col-md-4">
                            <canvas id="pieChart"></canvas>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-8">
                            <canvas id="lineChart"></canvas>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Client Section-->
            <section id="clients-section" class="section collapsed">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <!-- Add Client Button (Left) -->
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#clientModal">Add Client</button>

                    <!-- Search Bar (Right) -->
                    <div class="d-flex">
                        <select id="clientSearchKey" class="form-control w-auto">
                            <option value="client_id">Client ID</option>
                            <option value="name">Name</option>
                            <option value="meter_no">Meter Number</option>
                        </select>
                        <input type="text" id="clientSearchInput" class="form-control w-auto ml-2" placeholder="Search">
                        <button class="btn btn-link ml-2" onclick="searchTable('clients-table', 'clientSearchKey', 'clientSearchInput')">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>

                <table class="table table-striped mt-3" id="clients-table">
                    <thead>
                        <tr>
                            <th>Client ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Meter Number</th>
                            <th>Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($client = mysqli_fetch_assoc($clientsResult)) { ?>
                            <tr>
                                <td data-key="client_id"><?php echo $client['client_id']; ?></td>
                                <td data-key="name"><?php echo $client['name']; ?></td>
                                <td><?php echo $client['email']; ?></td>
                                <td data-key="meter_no"><?php echo $client['meter_no']; ?></td>
                                <td><?php echo $client['address']; ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm dropdown-toggle" type="button" id="actionDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Action
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="actionDropdown">
                                            <a class="dropdown-item" data-toggle="modal" data-target="#viewclientModal" data-client-id="<?php echo $client['client_id']; ?>" onclick="loadClientData(<?php echo $client['client_id']; ?>)">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                            <a class="dropdown-item" data-toggle="modal" data-target="#editclientModal" data-client-id="<?php echo $client['client_id']; ?>" onclick="loadEditClientData(<?php echo $client['client_id']; ?>)">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <a class="dropdown-item text-danger" href="includes/delete_client.php?client_id=<?php echo $client['client_id']; ?>" onclick="return confirm('Are you sure you want to delete this user?');">
                                                <i class="fas fa-trash-alt"></i> Delete
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </section>

            <!--Payments Section -->
            <section id="payments-section" class="section collapsed">
                <!-- Search Bar -->
                <div class="d-flex justify-content-end mb-3">
                    <select id="paymentSearchKey" class="form-control w-auto">
                        <option value="client_id">Client ID</option>
                        <option value="payment_date">Payment Date</option>
                    </select>
                    <input type="text" id="paymentSearchInput" class="form-control w-auto ml-2" placeholder="Search">
                    <button class="btn btn-link ml-2" onclick="searchTable('payments-table', 'paymentSearchKey', 'paymentSearchInput')"><i class="fas fa-search"></i></button>
                </div>

                <table class="table table-striped mt-3" id="payments-table">
                    <thead>
                        <tr>
                            <th>Payment ID</th>
                            <th>Client ID</th>
                            <th>Amount</th>
                            <th>Payment Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($payment = mysqli_fetch_assoc($paymentsResult)) { ?>
                            <tr>
                                <td><?php echo $payment['payment_id']; ?></td>
                                <td data-key="client_id"><?php echo $payment['client_id']; ?></td>
                                <td><?php echo $payment['amount']; ?></td>
                                <td data-key="payment_date"><?php echo $payment['payment_date']; ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm dropdown-toggle" type="button" id="actionDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Action
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="actionDropdown">
                                            <a class="dropdown-item" data-toggle="modal" data-target="#paymentclientModal" data-payment-id="<?php echo $payment['payment_id']; ?>">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                            <a class="dropdown-item text-danger" href="includes/delete_payments.php?payment_id=<?php echo $payment['payment_id']; ?>" onclick="return confirm('Are you sure you want to delete this user?');">
                                                <i class="fas fa-trash-alt"></i> Delete
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </section>

            <!--Token Section -->
            <section id="tokens-section" class="section collapsed">
                <!-- Search Bar -->
                <div class="d-flex justify-content-end mb-3">
                    <select id="tokenSearchKey" class="form-control w-auto">
                        <option value="client_id">Client ID</option>
                        <option value="token">Token</option>
                        <option value="issue_date">Issue Date</option>
                    </select>
                    <input type="text" id="tokenSearchInput" class="form-control w-auto ml-2" placeholder="Search">
                    <button class="btn btn-link ml-2" onclick="searchTable('tokens-table', 'tokenSearchKey', 'tokenSearchInput')"><i class="fas fa-search"></i></button>
                </div>

                <table class="table table-striped mt-3" id="tokens-table">
                    <thead>
                        <tr>
                            <th>Token ID</th>
                            <th>Client ID</th>
                            <th>Token</th>
                            <th>Issue Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($token = mysqli_fetch_assoc($tokensResult)) { ?>
                            <tr>
                                <td><?php echo $token['token_id']; ?></td>
                                <td data-key="client_id"><?php echo $token['client_id']; ?></td>
                                <td data-key="token"><?php echo $token['token']; ?></td>
                                <td data-key="issue_date"><?php echo $token['issue_date']; ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm dropdown-toggle" type="button" id="actionDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Action
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="actionDropdown">
                                            <a class="dropdown-item" data-toggle="modal" data-target="#tokenclientModal" data-token-id="<?php echo $token['token_id']; ?>">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                            <a class="dropdown-item text-danger" href="includes/delete_token.php?token_id=<?php echo $token['token_id']; ?>" onclick="return confirm('Are you sure you want to delete this user?');">
                                                <i class="fas fa-trash-alt"></i> Delete
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </section>

            <!--Logs-section-->
            <section id="logs-section" class="section collapsed">
                <table class="table table-striped mt-3">
                    <thead>
                        <tr>
                            <th>log ID</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($log = mysqli_fetch_assoc($logsResult)) { ?>
                            <tr>
                                <td><?php echo $log['log_id']; ?></td>
                                <td><?php echo $log['action']; ?></td>
                                <td><?php echo $log['timestamp']; ?></td>
                                <td>
                                   <div class="dropdown-menu" aria-labelledby="actionDropdown">
                                        <!-- View logs -->
                                        <a class="dropdown-item" href="includes/logs_client.php?log_id=<?php echo $user['id']; ?>">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <!-- Delete logs -->
                                        <a class="dropdown-item text-danger" href="includes/delete_logs.php?log_id=<?php echo $user['id']; ?>" onclick="return confirm('Are you sure you want to delete this user?');">
                                            <i class="fas fa-trash-alt"></i> Delete
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </section>
            
            <!-- Profile Section -->
            <section id="profile-section" style="section collapsed">
                <div class="container1 ">
                    <div class="row">
                        <!-- Left Section: User Information -->
                        <div class="col-md-6 text-center">
                            <div class="profile-image ms-4">
                                <!-- Display profile image or default icon -->
                                <?php if (!empty($profileImage)) { ?>
                                        <img src="<?php echo $profileImage; ?>" alt="Profile Image" 
                                        class="img-fluid rounded-circle" 
                                        style="width: 150px; height: 150px; object-fit: cover; object-position: center;">
                                <?php } else { ?>
                                    <i class="fa fa-user-circle" style="font-size: 150px; color: gray;"></i>
                                <?php } ?>
                            </div>
                            <div class="user-info">
                                <p><strong>Username:</strong> <span><?php echo $username; ?></span></p>
                                <p><strong>Role:</strong> <span><?php echo $role; ?></span></p>
                            </div>
                        </div>

                        <!-- Right Section: Profile Image and Update Info Toggle -->
                        <div class="col-md-6 border-start">
                            <div class="toggle-buttons text-center mb-3">
                                <button class="btn btn-primary me-2" onclick="showSection('profile_image-section')">Profile Image</button>
                                <button class="btn btn-secondary" onclick="showSection('update-info-section')">Update Information</button>
                            </div>
                            <!-- Profile Image Section -->
                            <div id="profile_image-section" class="section-content text-center">
                                <h3>Profile Image</h3>
                                <div class="profile_image">
                                    <?php
                                        $file_ext = isset($data['filename']) ? strtolower(pathinfo($data['filename'], PATHINFO_EXTENSION)) : '';
                                        if (!empty($data['filename']) && in_array($file_ext, ['jpg', 'jpeg', 'png'])) {
                                            echo "<img src='uploads/profile/{$data['filename']}' class='file-view' id='profile_image-img' alt='Profile Image'>";
                                        } else {
                                            echo "<i class='fa fa-user-circle' id='default-profile_image' style='font-size: 150px; color: gray;'></i>";
                                        }
                                    ?>
                                    <input type="file" id="profile_image-input" style="display: none;" accept="image/*">
                                    <button class="btn btn-success mt-2" id="upload-profile_image">Upload</button>
                                    <button class="btn btn-danger mt-2" id="delete-profile_image">Delete</button>
                                </div>
                            </div>
                            <!-- Update Information Section -->
                            <div id="update-info-section" class="section-content" style="display: none;">
                                <h3>Update Information</h3>
                                <form id="update-info-form" method="POST" action="includes/update_profile.php">
                                    <div class="mb-2">
                                        <label for="new-username" class="form-label">Username</label>
                                        <input type="text" name="username" class="form-control" id="new-username" required>
                                    </div>
                                    <div class="mb-2">
                                        <label for="old-password" class="form-label">Old Password</label>
                                        <input type="password" name="old_password" class="form-control" id="old-password" required>
                                    </div>
                                    <div class="mb-2">
                                        <label for="new-password" class="form-label">New Password</label required>
                                        <input type="password" name="new_password" class="form-control" id="new-password">
                                    </div>
                                    <div class="mb-2">
                                        <label for="confirm-password" class="form-label">Confirm New Password</label required>
                                        <input type="password"name="confirm_password" class="form-control" id="confirm-password">
                                    </div>
                                    <button type="submit" class="btn btn-primary w-100">Update</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Notification Details Container (Hidden Initially) -->
            <section class="notification-details-container" id="notification-section" style="section collapsed">
                <div class="notification-details">
                    <h1>Notification Details</h1>
                    <p><strong>Type:</strong> <span id="notification-type"></span></p>
                    <p><strong>Message:</strong> <span id="notification-message"></span></p>
                    <p><strong>Status:</strong> <span id="notification-status"></span></p>
                    <p><strong>Created At:</strong> <span id="notification-created"></span></p>
                </div>
            </section>
        </main>
    </div>

    <!-- add client -->
    <div class="modal fade" id="clientModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Client</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action="includes/save_client.php" method="POST">
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label for="client_id">Client ID</label>
                            <input type="text" class="form-control" name="client_id" id="client_id" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="name" id="name" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" id="password" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="meter_no">Meter Number</label>
                            <input type="text" class="form-control" name="meter_no" id="meter_no" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" name="address" id="address" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save Client</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Client Modal -->
    <div class="modal fade" id="editclientModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Client</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action="includes/edit_client.php" method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="client_id" id="edit_client_id">
                        <div class="form-group">
                            <label for="edit_name">Name</label>
                            <input type="text" class="form-control" name="name" id="edit_name" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_email">Email</label>
                            <input type="email" class="form-control" name="email" id="edit_email" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_address">Address</label>
                            <input type="text" class="form-control" name="address" id="edit_address" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_meter_no">Meter Number</label>
                            <input type="text" class="form-control" name="meter_no" id="edit_meter_no"  required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- view Client Modal -->
    <div class="modal fade" id="viewclientModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">View Client</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="user-info">
                        <p><strong>Client Number:</strong> <span id="clientId"></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Username:</strong> <span id="clientName"></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Email:</strong> <span id="clientEmail"></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Address:</strong> <span id="clientAddress"></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Meter Number:</strong> <span id="clientMeterNo"></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- view Payment Modal -->
    <div class="modal fade" id="paymentclientModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">View Payment</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="user-info">
                        <p><strong>Client Number:</strong> <span><?php echo $client_id; ?></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Payment Date:</strong> <span><?php echo $payment_date; ?></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Amount:</strong> <span><?php echo $amount; ?></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Payment Status:</strong> <span><?php echo $payment_status; ?></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- view Token Modal -->
    <div class="modal fade" id="tokenclientModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">View Token</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="user-info">
                        <p><strong>Client Number:</strong> <span><?php echo $client_id; ?></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Token Number:</strong> <span><?php echo $token_value; ?></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Date Issued:</strong> <span><?php echo $issue_date; ?></span></p>
                    </div>
                    <div class="user-info">
                        <p><strong>Expiry Date:</strong> <span><?php echo $expiry_date; ?></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2025 AquaPay | All Rights Reserved. Zac</p>
    </footer>


    <!-- Bootstrap JS (for modal functionality) -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Bootstrap JS (Required for dropdown) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="styles/script.js"></script>

    <script>
        // Bar chart for water usage
        const ctx = document.getElementById('waterUsageChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Users', 'Tokens', 'Payments'], // X-axis labels
                datasets: [{
                    label: 'Total Count',
                    data: [<?php echo $totalUsers; ?>, <?php echo $totalTokens; ?>, <?php echo $totalPayments; ?>], // Data for each category
                    backgroundColor: 'rgba(22, 149, 149, 0.6)', // Bar color
                    borderColor: 'rgb(14, 99, 99)', // Border color
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: { 
                        beginAtZero: true 
                    }
                }
            }
        });

        // Pie chart
        const pieCtx = document.getElementById('pieChart').getContext('2d');
        new Chart(pieCtx, {
            type: 'pie',
            data: {
                labels: ['Users', 'Tokens', 'Payments'], // Pie chart labels
                datasets: [{
                    label: 'Distribution',
                    data: [<?php echo $totalUsers; ?>, <?php echo $totalTokens; ?>, <?php echo $totalPayments; ?>], // Pie chart data
                    backgroundColor: ['#22A99F', '#FFB55D', '#FF6B6B'], // Different colors for each segment
                    borderColor: ['#16A9A3', '#FF9F1C', '#FF3D29'], // Border color for each segment
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                return tooltipItem.label + ': ' + tooltipItem.raw;
                            }
                        }
                    }
                }
            }
        });

        // Line chart
        const lineCtx = document.getElementById('lineChart').getContext('2d');
        new Chart(lineCtx, {
            type: 'line',
            data: {
                labels: ['Users', 'Tokens', 'Payments'], // X-axis labels
                datasets: [{
                    label: 'Line Chart',
                    data: [<?php echo $totalUsers; ?>, <?php echo $totalTokens; ?>, <?php echo $totalPayments; ?>], // Pie chart data
                    fill: false,
                    borderColor: '#007bff',
                    tension: 0.1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        
        //mark notification read.
        $(document).on('click', '.notification-link', function () {
            var notificationId = $(this).data('id'); // Get notification_id from the clicked item
            
            // Call function to load details
            loadNotificationData(notificationId); 

            // Update notification status to 'read'
            $.ajax({
                url: 'includes/update_notification_status.php', // New PHP file to handle the status update
                method: 'POST',
                data: { notification_id: notificationId },
                success: function(response) {
                    try {
                        var result = JSON.parse(response);

                        if (result.success) {
                            // Update the unread notification count
                            var unreadCount = parseInt($('#notification-count').text()) - 1;
                            $('#notification-count').text(unreadCount);
                        } else {
                            console.error('Failed to update notification status');
                        }
                    } catch (e) {
                        console.error("Error parsing JSON:", e, response);
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error:", status, error);
                }
            });
        });



        // When the notification bell is clicked
        // $('#notification-bell').on('click', function() {
        //     $.ajax({
        //         url: 'includes/fetch_unread_count.php', 
        //         method: 'GET',
        //         success: function(response) {
        //             try {
        //                 var data = JSON.parse(response);
                        
        //                 if (data.success) {
        //                     var unreadCount = data.unread_count;
        //                     $('#notification-count').text(unreadCount);
                        
        //                     if (unreadCount === 0) {
        //                         $('.notification-dropdown .notification-list').html('<li class="notification-item no-notifications">No new notifications</li>');
        //                     } else {
        //                         var notificationsHTML = '';
        //                         $.each(data.notifications, function(index, notification) {
        //                             notificationsHTML += '<li class="notification-item">';
        //                             notificationsHTML += '<a href="javascript:void(0);" class="notification-link" data-id="' + notification.notification_id + '" data-type="' + notification.notification_type + '" data-message="' + notification.message + '" data-status="' + notification.status + '" data-created="' + notification.created_at + '">' + notification.message + '</a>';
        //                             notificationsHTML += '</li>';
        //                         });
        //                         $('.notification-dropdown .notification-list').html(notificationsHTML);
        //                     }
        //                 } else {
        //                     console.error('Failed to fetch unread count');
        //                 }
        //             } catch (e) {
        //                 console.error("Error parsing JSON:", e, response);
        //             }
        //         },
        //         error: function(xhr, status, error) {
        //             console.error("AJAX Error:", status, error);
        //         }
        //     });
        // });

    </script>
</body>
</html>
