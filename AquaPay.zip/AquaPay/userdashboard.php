<?php
session_start();
include 'includes/db.php';

if(!isset($_SESSION['loggedInUser']) || !isset($_SESSION['client_id'])) {
    header("Location: AdminLogin.php");
    exit();
}

$loggedInUser = $_SESSION['loggedInUser'];
$user_id = $_SESSION['client_id'];

// Fetch user information (name, email & profile image) using client_id
$queryUser = "SELECT client_id, name, meter_no, status, email, profile_image, address FROM client_information WHERE client_id = '$user_id'";
$resultUser = mysqli_query($conn, $queryUser);

if ($resultUser && mysqli_num_rows($resultUser) > 0) {
    $userData = mysqli_fetch_assoc($resultUser);
    $name = $userData['name'];
    $email = $userData['email'];
    $profileImage = !empty($userData['profile_image']) ? $userData['profile_image'] : 'default.png';
    $client_id = $userData['client_id'];
    $address = $userData['address'];
    $meter_no = $userData['meter_no'];
    $status = $userData['status'];
} else {
    $name = "Unknown";
    $email = "No email found";
    $profileImage = "default.png";
    $client_id = "Unknown";
    $address = "Not provided";
    $meter_no = "Unknown";
    $status = "Unknown";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AquaPay Client Portal</title>
    <!--Favicon-->
    <link rel="icon" type="image/png" href="images/icon.png">
    <!--styling-->
    <link rel="stylesheet" href="styles/style5.css">
    <!-- FontAwesome for icons -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">

</head>
<body>
    <!-- Topbar -->
    <div class="top-bar" id="topbar">
        <div class="left">
            <button class="navbar-toggler" id="sidebarToggle">
                <i class="fas fa-bars"></i> 
            </button>
        </div>
        <div class="right">
            <span>Hi, <?php echo htmlspecialchars($loggedInUser); ?></span>

            <div class="profile-dropdown">
                <?php if (!empty($profileImage)) { ?>
                    <img src="<?php echo $profileImage; ?>" alt="Profile Image" class="profile-icon" id="profile-toggle" style="width: 30px; height: 30px; border-radius: 50%;">
                <?php } else { ?>
                    <i class="fas fa-user-circle profile-icon" id="profile-toggle"></i>
                <?php } ?>
                <div class="dropdown-content" id="profile-dropdown">
                    <a class="dropdown-item" id="my-profile" href="javascript:void(0);">My Profile</a>
                    <a class="dropdown-item" href="includes/logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <aside class="sidebar" id="sidebar">
        <div class="d-flex align-items-center mb-3">
            <img src="images/icon.png" alt="logo" class="logo"/>
            <h4>Aquapay</h4>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
            <li class="nav-item"><a class="nav-link" href="code.php">Dashboard</a></li>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fas fa-money-bill-wave me-2"></i> Payments</a>
                <ul class="dropdown-content list-unstyled ps-3">
                    <li><a class="nav-link" href="#" id="view-make-payment"><i class="fas fa-money-bill me-2"></i> Make Payments</a></li>
                    <li><a class="nav-link" href="#" id="view-transactions"><i class="fas fa-history me-2"></i> Transactions</a></li>
                    <li><a class="nav-link" href="#" id="view-print"><i class="fas fa-print me-2"></i> Print Receipt</a></li>
                </ul>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" id="view-meter-info"><i class="fas fa-info-circle me-2"></i> Meter Info</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fas fa-question-circle me-2"></i> Contact Us</a>
                <ul class="dropdown-content list-unstyled ps-3">
                    <li><a class="nav-link" href="#" id="view-contact"><i class="fas fa-envelope me-2"></i> Contact us</a></li>
                    <li><a class="nav-link" href="#" id="view-faq"><i class="fas fa-question me-2"></i> FAQ</a></li>
                </ul>
            </li>
        </ul>
    </aside>
    <div class="overlay" id="overlay"></div>

    <!-- Main Container -->
    <div class="main-container" id="main-container">
        <div class="hero-section text-center text-white" style="background: url('images/water-usage.jpg') no-repeat center center / cover; height: 100%;">
            <div class="overlay"></div>
            <div class="hero-content">
                <h1 class="display-3 mb-3">Welcome to AquaPay</h1>
                <p class="lead mb-4">Manage your water bills easily and securely from anywhere, anytime.</p>
                <a href="#" class="btn btn-primary btn-lg">Learn More</a>
            </div>
        </div>


        <!-- Profile Section -->
        <section id="profile-section" class="aqua-section" style="display: none;">
            <div class="container1 ">
                <div class="row">
                    <!-- Left Section: User Information -->
                    <div class="col-md-6 text-center">
                        <div class="profile-image ms-4">
                            <!-- Display profile image or default icon -->
                            <?php if (!empty($profileImage)) { ?>
                                    <img src="<?php echo $profileImage; ?>" alt="Profile Image" 
                                    class="img-fluid rounded-circle" 
                                    style="width: 180px; height: 180px; object-fit: cover; object-position: center;">
                            <?php } else { ?>
                                <i class="fa fa-user-circle" style="font-size: 150px; color: gray;"></i>
                            <?php } ?>
                        </div>
                        <div class="user-info">
                            <p><strong>Client Number:</strong> <span><?php echo $client_id; ?></span></p>    
                            <p><strong>Username:</strong> <span><?php echo $name; ?></span></p>
                            <p><strong>Email:</strong> <span><?php echo $email; ?></span></p>
                            <p><strong>Address:</strong> <span><?php echo $address; ?></span></p>
                        </div>
                    </div>

                    <!-- Right Section: Profile Image and Update Info Toggle -->
                    <div class="col-md-6 border-start">
                        <div class="toggle-buttons text-center mb-3">
                            <button class="btn btn-primary me-2" onclick="showSection('profile_image-section')">Profile Image</button>
                            <button class="btn btn-secondary" onclick="showSection('update-info-section')">Update Information</button>
                        </div>
                        <!-- Profile Image Section -->
                        <div id="profile_image-section" class="section-content text-center">
                            <h3>Profile Image</h3>
                            <div class="profile_image">
                                <?php
                                    $file_ext = isset($data['filename']) ? strtolower(pathinfo($data['filename'], PATHINFO_EXTENSION)) : '';
                                        if (!empty($data['filename']) && in_array($file_ext, ['jpg', 'jpeg', 'png'])) {
                                            echo "<img src='uploads/profile/{$data['filename']}' class='file-view' id='profile_image-img' alt='Profile Image'>";
                                        } else {
                                            echo "<i class='fa fa-user-circle' id='default-profile_image' style='font-size: 150px; color: gray;'></i>";
                                        }
                                ?>
                                <input type="file" id="profile_image-input" style="display: none;" accept="image/*">
                                <button class="btn btn-success mt-2" id="upload-profile_image">Upload</button>
                                <button class="btn btn-danger mt-2" id="delete-profile_image">Delete</button>
                            </div>
                        </div>
                        <!-- Update Information Section -->
                        <div id="update-info-section" class="section-content" style="display: none;">
                            <h3>Update Information</h3>
                            <form id="update-info-form" method="POST" action="includes/update_profile.php">
                                <div class="mb-2">
                                    <label for="new-username" class="form-label">Username</label>
                                    <input type="text" name="username" class="form-control" id="new-username" required>
                                </div>
                                <div class="mb-2">
                                    <label for="old-password" class="form-label">Old Password</label>
                                    <input type="password" name="old_password" class="form-control" id="old-password" required>
                                </div>
                                <div class="mb-2">
                                    <label for="new-password" class="form-label">New Password</label required>
                                    <input type="password" name="new_password" class="form-control" id="new-password">
                                </div>
                                <div class="mb-2">
                                    <label for="confirm-password" class="form-label">Confirm New Password</label required>
                                    <input type="password"name="confirm_password" class="form-control" id="confirm-password">
                                </div>
                                <button type="submit" class="btn btn-primary w-100">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Make Payment Section -->
        <section id="make-payment" class="aqua-section" style="display: none;">
        <h2>Make a Payment</h2>
            <form action="includes/pay_now.php" method="POST">
                <label>Phone Number:</label>
                <input type="text" name="phone" required placeholder="e.g. 0771234567"><br><br>

                <label>Amount (UGX):</label>
                <input type="number" name="amount" required min="1000" step="100"><br><br>

                <button type="submit">Pay Now</button>
            </form>
        </section>

        <!-- Transactions Section -->
        <section id="transactions" class="aqua-section" style="display: none;">
        <h2>Payment History</h2>
        <table>
            <thead>
            <tr><th>Date of Payment</th><th>Amount Paid</th><th>Status</th></tr>
            </thead>
            <tbody id="transaction-list">
            <!-- Fetched data from DB via PHP or JS -->
            </tbody>
        </table>
        </section>

        <!-- Print Receipt Section -->
        <section id="print-receipt" class="aqua-section" style="display: none;">
        <h2>Print Receipt</h2>
        <div id="receipt-list">
            <!-- Fetched receipts -->
            <button onclick="window.print()">Print Selected</button>
        </div>
        </section>

        <!-- Meter Info Section -->
        <section id="meter-info" class="aqua-section" style="display: none;">
            <h2>Meter Information</h2>
            <p>Meter No: <span id="meter-number"><?php echo htmlspecialchars($meter_no); ?></span></p>
            <p>Status: <span id="meter-status"><?php echo htmlspecialchars($status); ?></span></p>
            <p>Owner: <span id="meter-owner"><?php echo htmlspecialchars($name); ?></span></p>
            <p>Address: <span id="meter-address"><?php echo htmlspecialchars($address); ?></span></p>
        </section>

        <!-- Contact Us Section -->
        <section id="contact-us" class="aqua-section" style="display: none;">
            <h2>Contact Us</h2>
            <div class="contact-wrapper">
                <form action="includes/send_message.php" method="POST" enctype="multipart/form-data" class="contact-form">
                    <input type="text" name="name" placeholder="Your name" required>
                    <input type="email" name="email" placeholder="Your email" required>
                    <input type="text" name="subject" placeholder="Subject" required>
                    <textarea name="message" placeholder="Your message" required></textarea>
                    <label for="image">Attach image (optional):</label>
                    <input type="file" name="image" accept="image/*">
                    <button type="submit">Send Message</button>
                </form>

                <div class="contact-info">
                    <p><strong>Email:</strong> support@aquapay.com</p>
                    <p><strong>Phone:</strong> +256 783 953 940</p>
                    <p><strong>Address:</strong> Plot 10, Soroti Town, Uganda</p>
                    <a href="https://wa.me/256783953940" target="_blank">
                        <img src="images/whatsaap.jpeg" alt="Chat on WhatsApp" style="width: 50px; margin-top: 10px;">
                    </a>
                </div>
            </div>
        </section>


        <!-- FAQ Section -->
        <section id="faq" class="aqua-section" style="display: none;">
            <div class="container py-5">
                <!-- About AquaPay Section -->
                <div class="row align-items-center">
                    <div class="col-md-6 mb-4">
                        <h2>What is AquaPay?</h2>
                        <p style="font-size: 1.1rem; line-height: 1.7;">
                            AquaPay is a smart platform designed to simplify and digitalize your water bill payments.
                            Pay securely through Mobile Money, receive instant payment tokens, and track your transactions in real-time.
                            AquaPay makes water management as easy as paying for electricity (like Yaka).
                        </p>
                    </div>

                    <div class="col-md-6 mb-4">
                        <h2>Key Features</h2>
                        <ul style="font-size: 1.1rem; line-height: 2;">
                            <li>Instant Payment Token Generation</li>
                            <li>Real-Time Transaction Tracking</li>
                            <li>Secure Mobile Money and Bank Payments</li>
                            <li>Accessible Anywhere, Anytime</li>
                            <li>Transparent and Low Transaction Fees</li>
                        </ul>
                    </div>
                </div>
            </div>
            <h2>FAQs</h2>
            <div id="faq-list">
                <!-- Loaded from database -->
            </div>
            <form action="submit_question.php" method="POST">
                <textarea name="question" placeholder="Ask a question..." required></textarea>
                <button type="submit">Submit</button>
            </form>
        </section>

    </div>

    <!-- Token Popup Container -->
    <div id="token-popup" class="token-popup">
        <div class="popup-content">
            <span class="close-popup" onclick="closePopup()">&times;</span>
            <p id="popup-message">Token or error message will appear here</p>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer" id="footer">
    <p>&copy; 2025 AquaPay | All Rights Reserved. Zac</p>
    </footer>

    <!-- Bootstrap JS (for modal functionality) -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Bootstrap JS (Required for dropdown) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const profileToggle = document.getElementById('profile-toggle');
            const dropdownContent = document.getElementById('profile-dropdown');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('overlay');

            profileToggle.addEventListener('click', () => {
                dropdownContent.style.display = dropdownContent.style.display === 'block' ? 'none' : 'block';
            });

            document.addEventListener('click', function (e) {
                if (!e.target.closest('.right')) {
                    dropdownContent.style.display = 'none';
                }
            });

            sidebarToggle.addEventListener('click', function () {
                sidebar.classList.toggle('show');
                overlay.classList.toggle('show');
            });

            overlay.addEventListener('click', function () {
                sidebar.classList.remove('show');
                overlay.classList.remove('show');
            });

            window.addEventListener('resize', function () {
                if (window.innerWidth > 768) {
                    sidebar.classList.remove('show');
                    overlay.classList.remove('show');
                }
            });
        });


        document.addEventListener("DOMContentLoaded", function () {
            const dashboardOverview = document.querySelector(".hero-section");
            const sections = document.querySelectorAll(".aqua-section");

            function toggleSections(sectionId) {
                // Hide all other sections
                sections.forEach(section => section.style.display = "none");
                // Hide dashboard
                dashboardOverview.style.display = "none";
                // Show the target section
                const target = document.getElementById(sectionId);
                if (target) target.style.display = "block";
            }

            // Show Dashboard when dashboard link is clicked
            document.querySelector(".nav-link[href='code.php']").addEventListener("click", function (e) {
                e.preventDefault();
                dashboardOverview.style.display = "flex";
                sections.forEach(section => section.style.display = "none");
            });

            // Payment submenu
            document.getElementById("view-make-payment").addEventListener("click", function (e) {
                e.preventDefault();
                toggleSections("make-payment");
            });

            document.getElementById("view-transactions").addEventListener("click", function (e) {
                e.preventDefault();
                toggleSections("transactions");
            });

            document.getElementById("view-print").addEventListener("click", function (e) {
                e.preventDefault();
                toggleSections("print-receipt");
            });

            // Meter Info
            document.getElementById("view-meter-info").addEventListener("click", function (e) {
                e.preventDefault();
                toggleSections("meter-info");
            });

            // Contact submenu
            document.getElementById("view-contact").addEventListener("click", function (e) {
                e.preventDefault();
                toggleSections("contact-us");
            });

            document.getElementById("view-faq").addEventListener("click", function (e) {
                e.preventDefault();
                toggleSections("faq");
            });  
            
            // Profile section under profile dropdown
            document.getElementById("my-profile").addEventListener("click", function (e) {
                e.preventDefault();
                toggleSections("profile-section");
            });
        });

        //My profile nav toggles 
        function showSection(section) {
        // Hide all sections
        const sections = document.querySelectorAll('.section-content');
        sections.forEach((section) => {
            section.style.display = 'none';
        });

        // Remove active class from all navbar buttons
        const buttons = document.querySelectorAll('.nav-btn');
        buttons.forEach((btn) => {
            btn.classList.remove('active');
        });

        // Show the clicked section
        document.getElementById(section).style.display = 'block';

        // Add active class to the clicked button
        const activeBtn = document.querySelector(`.nav-btn[onclick="showSection('${section}')"]`);
        activeBtn.classList.add('active');
        }


        //my profile-image
        document.addEventListener("DOMContentLoaded", function () {
            const profileImg = document.getElementById("profile_image-img");
            const defaultProfileIcon = document.getElementById("default-profile_image");
            const fileInput = document.getElementById("profile_image-input");
            const uploadButton = document.getElementById("upload-profile_image");

            // Clicking the profile image or default icon opens the file input
            [profileImg, defaultProfileIcon].forEach(element => {
                if (element) element.addEventListener("click", () => fileInput.click());
            });

            // When a file is selected, preview it and upload
            fileInput.addEventListener("change", function () {
                if (fileInput.files.length === 0) return; // No file selected

                const file = fileInput.files[0];

                // Check file type
                const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
                if (!allowedTypes.includes(file.type)) {
                    alert("Only JPG, JPEG, and PNG files are allowed.");
                    return;
                }

                const reader = new FileReader();
                reader.onload = function (e) {
                    if (profileImg) {
                        profileImg.src = e.target.result;
                    } else {
                        const newImg = document.createElement("img");
                        newImg.src = e.target.result;
                        newImg.className = "file-view";
                        newImg.id = "profile_image-img";
                        defaultProfileIcon.replaceWith(newImg);
                        newImg.addEventListener("click", () => fileInput.click());
                    }
                };
                reader.readAsDataURL(file);

                uploadProfileImage(file);
            });

            // Function to upload profile image
            async function uploadProfileImage(file) {
                try {
                    let formData = new FormData();
                    formData.append("profile_image", file);

                    let response = await fetch("includes/uploadClient_profile.php", {
                        method: "POST",
                        body: formData,
                    });

                    let result = await response.text();
                    alert(result); // Show response message
                    location.reload(); // Refresh page to reflect the new profile image
                } catch (error) {
                    console.error("Upload error:", error);
                }
            }
        });

        document.querySelector('input[name="image"]').addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                if (!allowedTypes.includes(file.type)) {
                    alert("Only JPG, PNG, and GIF files are allowed.");
                    event.target.value = '';
                } else if (file.size > 2 * 1024 * 1024) {
                    alert("Image must be less than 2MB.");
                    event.target.value = '';
                } else {
                    const preview = document.createElement("img");
                    preview.src = URL.createObjectURL(file);
                    preview.style.maxWidth = "100px";
                    document.querySelector(".contact-form").appendChild(preview);
                }
            }
        });

        function showPopup(message) {
            document.getElementById('popup-message').innerText = message;
            document.getElementById('token-popup').style.display = 'block';
        }

        function closePopup() {
            document.getElementById('token-popup').style.display = 'none';
        }
    </script>
</body>
</html>